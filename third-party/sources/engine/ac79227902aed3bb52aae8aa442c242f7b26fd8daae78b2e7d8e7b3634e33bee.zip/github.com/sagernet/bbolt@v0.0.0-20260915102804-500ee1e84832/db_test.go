package bbolt_test

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/fnv"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
	"unsafe"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	bolt "github.com/sagernet/bbolt"
	berrors "github.com/sagernet/bbolt/errors"
	"github.com/sagernet/bbolt/internal/btesting"
	"github.com/sagernet/bbolt/internal/common"
	"github.com/sagernet/bbolt/internal/guts_cli"
)

// pageSize is the size of one page in the data file.
const pageSize = 4096

// pageHeaderSize is the size of a page header.
const pageHeaderSize = 16

// meta represents a simplified version of a database meta page for testing.
type meta struct {
	_       uint32
	version uint32
	_       uint32
	_       uint32
	_       [16]byte
	_       uint64
	pgid    uint64
	_       uint64
	_       uint64
}

// Ensure that a database can be opened without error.
func TestOpen(t *testing.T) {
	path := tempfile()
	defer os.RemoveAll(path)

	db, err := bolt.Open(path, 0600, nil)
	if err != nil {
		t.Fatal(err)
	} else if db == nil {
		t.Fatal("expected db")
	}

	if s := db.Path(); s != path {
		t.Fatalf("unexpected path: %s", s)
	}

	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
}

// Ensure that a second Open of a database file that is already open in this
// process times out. bbolt's file lock is owned by the open file description,
// so it excludes other handles within a process just as it excludes other
// processes. See https://github.com/etcd-io/bbolt/issues/558.
func TestOpen_ErrTimeout_SameProcess(t *testing.T) {
	switch runtime.GOOS {
	case "aix", "solaris":
		// These platforms lock with POSIX record locks, which are owned by
		// the process.
		t.Skip("file locks on this platform are process-owned")
	}

	path := tempfile()
	defer os.RemoveAll(path)

	db, err := bolt.Open(path, 0600, nil)
	require.NoError(t, err)
	defer func() {
		require.NoError(t, db.Close())
	}()

	_, err = bolt.Open(path, 0600, &bolt.Options{Timeout: 100 * time.Millisecond})
	require.ErrorIs(t, err, berrors.ErrTimeout)
}

// Regression validation for https://github.com/etcd-io/bbolt/pull/122.
// Tests multiple goroutines simultaneously opening a database.
func TestOpen_MultipleGoroutines(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping test in short mode")
	}

	const (
		instances  = 30
		iterations = 30
	)
	path := tempfile()
	defer os.RemoveAll(path)
	var wg sync.WaitGroup
	errCh := make(chan error, iterations*instances)
	for iteration := 0; iteration < iterations; iteration++ {
		for instance := 0; instance < instances; instance++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				db, err := bolt.Open(path, 0600, nil)
				if err != nil {
					errCh <- err
					return
				}
				if err := db.Close(); err != nil {
					errCh <- err
					return
				}
			}()
		}
		wg.Wait()
	}
	close(errCh)
	for err := range errCh {
		if err != nil {
			t.Fatalf("error from inside goroutine: %v", err)
		}
	}
}

// Ensure that opening a database with a blank path returns an error.
func TestOpen_ErrPathRequired(t *testing.T) {
	_, err := bolt.Open("", 0600, nil)
	if err == nil {
		t.Fatalf("expected error")
	}
}

// Ensure that opening a database with a bad path returns an error.
func TestOpen_ErrNotExists(t *testing.T) {
	_, err := bolt.Open(filepath.Join(tempfile(), "bad-path"), 0600, nil)
	if err == nil {
		t.Fatal("expected error")
	}
}

// Ensure that opening a file that is not a Bolt database returns ErrInvalid.
func TestOpen_ErrInvalid(t *testing.T) {
	path := tempfile()
	defer os.RemoveAll(path)

	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := fmt.Fprintln(f, "this is not a bolt database"); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}

	if _, err := bolt.Open(path, 0600, nil); err != berrors.ErrInvalid {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure that opening a file with two invalid versions returns ErrVersionMismatch.
func TestOpen_ErrVersionMismatch(t *testing.T) {
	if pageSize != os.Getpagesize() {
		t.Skip("page size mismatch")
	}

	// Create empty database.
	db := btesting.MustCreateDB(t)
	path := db.Path()

	// Close database.
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}

	// Read data file.
	buf, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	// Rewrite meta pages.
	meta0 := (*meta)(unsafe.Pointer(&buf[pageHeaderSize]))
	meta0.version++
	meta1 := (*meta)(unsafe.Pointer(&buf[pageSize+pageHeaderSize]))
	meta1.version++
	if err := os.WriteFile(path, buf, 0666); err != nil {
		t.Fatal(err)
	}

	// Reopen data file.
	if _, err := bolt.Open(path, 0600, nil); err != berrors.ErrVersionMismatch {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure that opening a file with two invalid checksums returns ErrChecksum.
func TestOpen_ErrChecksum(t *testing.T) {
	if pageSize != os.Getpagesize() {
		t.Skip("page size mismatch")
	}

	// Create empty database.
	db := btesting.MustCreateDB(t)
	path := db.Path()

	// Close database.
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}

	// Read data file.
	buf, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	// Rewrite meta pages.
	meta0 := (*meta)(unsafe.Pointer(&buf[pageHeaderSize]))
	meta0.pgid++
	meta1 := (*meta)(unsafe.Pointer(&buf[pageSize+pageHeaderSize]))
	meta1.pgid++
	if err := os.WriteFile(path, buf, 0666); err != nil {
		t.Fatal(err)
	}

	// Reopen data file.
	if _, err := bolt.Open(path, 0600, nil); err != berrors.ErrChecksum {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure that opening a file whose meta page points the freelist at a page
// that is not a freelist page returns ErrInvalid instead of panicking.
func TestOpen_ErrInvalid_FreelistPage(t *testing.T) {
	bucketName := []byte("data")
	db := btesting.MustCreateDBWithOption(t, &bolt.Options{PageSize: 4096})
	err := db.Fill(bucketName, 1, 100,
		func(tx int, k int) []byte { return []byte(fmt.Sprintf("%04d", k)) },
		func(tx int, k int) []byte { return make([]byte, 100) },
	)
	require.NoError(t, err)
	bucketRootPageId := mustGetBucketRootPage(t, db.DB, bucketName)
	path := db.Path()
	db.MustClose()

	t.Log("Pointing the freelist of the active meta page at the bucket root page.")
	_, activeMetaPageId, err := guts_cli.GetRootPage(path)
	require.NoError(t, err)
	_, metaPageBuf, err := guts_cli.ReadPage(path, uint64(activeMetaPageId))
	require.NoError(t, err)
	activeMeta := common.LoadPageMeta(metaPageBuf)
	activeMeta.SetFreelist(bucketRootPageId)
	activeMeta.SetChecksum(activeMeta.Sum64())
	require.NoError(t, guts_cli.WritePage(path, metaPageBuf))

	_, err = bolt.Open(path, 0600, &bolt.Options{PageSize: 4096})
	require.ErrorIs(t, err, berrors.ErrInvalid)
}

// Ensure that opening a file without a synced freelist returns ErrInvalid
// when the scan that rebuilds the freelist runs into a bucket nested in itself.
func TestOpen_ErrInvalid_NoFreelistSync_BucketCycle(t *testing.T) {
	options := &bolt.Options{PageSize: 4096, NoFreelistSync: true}
	path := createBucketCycle(t, options)

	_, err := bolt.Open(path, 0600, options)
	require.ErrorIs(t, err, berrors.ErrInvalid)
}

// Ensure that it can read the page size from the second meta page if the first one is invalid.
// The page size is expected to be the OS's page size in this case.
func TestOpen_ReadPageSize_FromMeta1_OS(t *testing.T) {
	// Create empty database.
	db := btesting.MustCreateDB(t)
	path := db.Path()
	// Close the database
	db.MustClose()

	// Read data file.
	buf, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	// Rewrite first meta page.
	meta0 := (*meta)(unsafe.Pointer(&buf[pageHeaderSize]))
	meta0.pgid++
	if err := os.WriteFile(path, buf, 0666); err != nil {
		t.Fatal(err)
	}

	// Reopen data file.
	db = btesting.MustOpenDBWithOption(t, path, nil)
	require.Equalf(t, os.Getpagesize(), db.Info().PageSize, "check page size failed")
}

// Ensure that it can read the page size from the second meta page if the first one is invalid.
// The page size is expected to be the given page size in this case.
func TestOpen_ReadPageSize_FromMeta1_Given(t *testing.T) {
	// test page size from 1KB (1024<<0) to 16MB(1024<<14)
	for i := 0; i <= 14; i++ {
		givenPageSize := 1024 << uint(i)
		t.Logf("Testing page size %d", givenPageSize)
		// Create empty database.
		db := btesting.MustCreateDBWithOption(t, &bolt.Options{PageSize: givenPageSize})
		path := db.Path()
		// Close the database
		db.MustClose()

		// Read data file.
		buf, err := os.ReadFile(path)
		require.NoError(t, err)

		// Rewrite meta pages.
		if i%3 == 0 {
			t.Logf("#%d: Intentionally corrupt the first meta page for pageSize %d", i, givenPageSize)
			meta0 := (*meta)(unsafe.Pointer(&buf[pageHeaderSize]))
			meta0.pgid++
			err = os.WriteFile(path, buf, 0666)
			require.NoError(t, err)
		}

		// Reopen data file.
		db = btesting.MustOpenDBWithOption(t, path, nil)
		require.Equalf(t, givenPageSize, db.Info().PageSize, "check page size failed")
		db.MustClose()
	}
}

// Ensure that opening a database does not increase its size.
// https://github.com/boltdb/bolt/issues/291
func TestOpen_Size(t *testing.T) {
	// Open a data file.
	db := btesting.MustCreateDB(t)

	pagesize := db.Info().PageSize

	// Insert until we get above the minimum 4MB size.
	err := db.Fill([]byte("data"), 1, 10000,
		func(tx int, k int) []byte { return []byte(fmt.Sprintf("%04d", k)) },
		func(tx int, k int) []byte { return make([]byte, 1000) },
	)
	if err != nil {
		t.Fatal(err)
	}

	path := db.Path()
	db.MustClose()

	sz := fileSize(path)
	if sz == 0 {
		t.Fatalf("unexpected new file size: %d", sz)
	}

	db.MustReopen()
	if err := db.Update(func(tx *bolt.Tx) error {
		if err := tx.Bucket([]byte("data")).Put([]byte{0}, []byte{0}); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	newSz := fileSize(path)
	if newSz == 0 {
		t.Fatalf("unexpected new file size: %d", newSz)
	}

	// Compare the original size with the new size.
	// db size might increase by a few page sizes due to the new small update.
	if sz < newSz-5*int64(pagesize) {
		t.Fatalf("unexpected file growth: %d => %d", sz, newSz)
	}
}

// Ensure that opening a database beyond the max step size does not increase its size.
// https://github.com/boltdb/bolt/issues/303
func TestOpen_Size_Large(t *testing.T) {
	if testing.Short() {
		t.Skip("short mode")
	}

	// Open a data file.
	db := btesting.MustCreateDB(t)
	path := db.Path()

	pagesize := db.Info().PageSize

	// Insert until we get above the minimum 4MB size.
	var index uint64
	for i := 0; i < 10000; i++ {
		if err := db.Update(func(tx *bolt.Tx) error {
			b, _ := tx.CreateBucketIfNotExists([]byte("data"))
			for j := 0; j < 1000; j++ {
				if err := b.Put(u64tob(index), make([]byte, 50)); err != nil {
					t.Fatal(err)
				}
				index++
			}
			return nil
		}); err != nil {
			t.Fatal(err)
		}
	}

	// Close database and grab the size.
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	sz := fileSize(path)
	if sz == 0 {
		t.Fatalf("unexpected new file size: %d", sz)
	} else if sz < (1 << 30) {
		t.Fatalf("expected larger initial size: %d", sz)
	}

	// Reopen database, update, and check size again.
	db0, err := bolt.Open(path, 0600, nil)
	if err != nil {
		t.Fatal(err)
	}
	if err := db0.Update(func(tx *bolt.Tx) error {
		return tx.Bucket([]byte("data")).Put([]byte{0}, []byte{0})
	}); err != nil {
		t.Fatal(err)
	}
	if err := db0.Close(); err != nil {
		t.Fatal(err)
	}

	newSz := fileSize(path)
	if newSz == 0 {
		t.Fatalf("unexpected new file size: %d", newSz)
	}

	// Compare the original size with the new size.
	// db size might increase by a few page sizes due to the new small update.
	if sz < newSz-5*int64(pagesize) {
		t.Fatalf("unexpected file growth: %d => %d", sz, newSz)
	}
}

// Ensure that a re-opened database is consistent.
func TestOpen_Check(t *testing.T) {
	path := tempfile()
	defer os.RemoveAll(path)

	db, err := bolt.Open(path, 0600, nil)
	if err != nil {
		t.Fatal(err)
	}
	if err = db.View(func(tx *bolt.Tx) error { return <-tx.Check() }); err != nil {
		t.Fatal(err)
	}
	if err = db.Close(); err != nil {
		t.Fatal(err)
	}

	db, err = bolt.Open(path, 0600, nil)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.View(func(tx *bolt.Tx) error { return <-tx.Check() }); err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
}

// Ensure that write errors to the meta file handler during initialization are returned.
func TestOpen_MetaInitWriteError(t *testing.T) {
	t.Skip("pending")
}

// Ensure that a database that is too small returns an error.
func TestOpen_FileTooSmall(t *testing.T) {
	path := tempfile()
	defer os.RemoveAll(path)

	db, err := bolt.Open(path, 0600, nil)
	if err != nil {
		t.Fatal(err)
	}
	pageSize := int64(db.Info().PageSize)
	if err = db.Close(); err != nil {
		t.Fatal(err)
	}

	// corrupt the database
	if err = os.Truncate(path, pageSize); err != nil {
		t.Fatal(err)
	}

	_, err = bolt.Open(path, 0600, nil)
	if err == nil || !strings.Contains(err.Error(), "file size too small") {
		t.Fatalf("unexpected error: %s", err)
	}
}

// TestDB_Open_InitialMmapSize tests if having InitialMmapSize large enough
// to hold data from concurrent write transaction resolves the issue that
// read transaction blocks the write transaction and causes deadlock.
// This is a very hacky test since the mmap size is not exposed.
func TestDB_Open_InitialMmapSize(t *testing.T) {
	tests := []struct {
		name       string
		withReadTx bool
	}{
		{
			name:       "with concurrent read transaction",
			withReadTx: true,
		},
		{
			name:       "without concurrent read transaction",
			withReadTx: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			path := tempfile()
			defer os.Remove(path)

			initMmapSize := 1 << 30  // 1GB
			testWriteSize := 1 << 27 // 134MB

			db, err := bolt.Open(path, 0600, &bolt.Options{InitialMmapSize: initMmapSize})
			if err != nil {
				t.Fatal(err)
			}
			defer db.Close()

			var rtx *bolt.Tx
			if tt.withReadTx {
				// create a long-running read transaction
				// that never gets closed while writing
				rtx, err = db.Begin(false)
				if err != nil {
					t.Fatal(err)
				}
			}

			// create a write transaction
			wtx, err := db.Begin(true)
			if err != nil {
				t.Fatal(err)
			}

			b, err := wtx.CreateBucket([]byte("test"))
			if err != nil {
				t.Fatal(err)
			}

			// commit a large write
			err = b.Put([]byte("foo"), make([]byte, testWriteSize))
			if err != nil {
				t.Fatal(err)
			}

			done := make(chan error, 1)
			start := time.Now()

			go func() {
				err := wtx.Commit()
				done <- err
			}()

			// Windows needs more time due to immediate file expansion to InitialMmapSize
			timeout := 5 * time.Second
			if runtime.GOOS == "windows" {
				timeout = 15 * time.Second
			}

			select {
			case <-time.After(timeout):
				t.Error("unexpected that the writer is blocked for a long time")
			case err := <-done:
				elapsed := time.Since(start)
				if err != nil {
					t.Fatal(err)
				}
				t.Logf("Write commit completed in %v", elapsed)
			}

			if rtx != nil {
				if err := rtx.Rollback(); err != nil {
					t.Fatal(err)
				}
			}
		})
	}
}

// TestDB_Open_ReadOnly checks a database in read only mode can read but not write.
func TestDB_Open_ReadOnly(t *testing.T) {
	// Create a writable db, write k-v and close it.
	db := btesting.MustCreateDB(t)

	if err := db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucket([]byte("widgets"))
		if err != nil {
			t.Fatal(err)
		}
		if err := b.Put([]byte("foo"), []byte("bar")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}

	f := db.Path()
	o := &bolt.Options{ReadOnly: true}
	readOnlyDB, err := bolt.Open(f, 0600, o)
	if err != nil {
		panic(err)
	}

	if !readOnlyDB.IsReadOnly() {
		t.Fatal("expect db in read only mode")
	}

	// Read from a read-only transaction.
	if err := readOnlyDB.View(func(tx *bolt.Tx) error {
		value := tx.Bucket([]byte("widgets")).Get([]byte("foo"))
		if !bytes.Equal(value, []byte("bar")) {
			t.Fatal("expect value 'bar', got", value)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}

	// Can't launch read-write transaction.
	if _, err := readOnlyDB.Begin(true); err != berrors.ErrDatabaseReadOnly {
		t.Fatalf("unexpected error: %s", err)
	}

	if err := readOnlyDB.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestDB_Open_ReadOnly_NoCreate(t *testing.T) {
	f := filepath.Join(t.TempDir(), "db")
	_, err := bolt.Open(f, 0600, &bolt.Options{ReadOnly: true})
	require.ErrorIs(t, err, os.ErrNotExist)
}

// TestOpen_BigPage checks the database uses bigger pages when
// changing PageSize.
func TestOpen_BigPage(t *testing.T) {
	pageSize := os.Getpagesize()

	db1 := btesting.MustCreateDBWithOption(t, &bolt.Options{PageSize: pageSize * 2})

	db2 := btesting.MustCreateDBWithOption(t, &bolt.Options{PageSize: pageSize * 4})

	if db1sz, db2sz := fileSize(db1.Path()), fileSize(db2.Path()); db1sz >= db2sz {
		t.Errorf("expected %d < %d", db1sz, db2sz)
	}
}

// TestOpen_RecoverFreeList tests opening the DB with free-list
// write-out after no free list sync will recover the free list
// and write it out.
func TestOpen_RecoverFreeList(t *testing.T) {
	db := btesting.MustCreateDBWithOption(t, &bolt.Options{NoFreelistSync: true})

	// Write some pages.
	tx, err := db.Begin(true)
	if err != nil {
		t.Fatal(err)
	}
	wbuf := make([]byte, 8192)
	for i := 0; i < 100; i++ {
		s := fmt.Sprintf("%d", i)
		b, err := tx.CreateBucket([]byte(s))
		if err != nil {
			t.Fatal(err)
		}
		if err = b.Put([]byte(s), wbuf); err != nil {
			t.Fatal(err)
		}
	}
	if err = tx.Commit(); err != nil {
		t.Fatal(err)
	}

	// Generate free pages.
	if tx, err = db.Begin(true); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 50; i++ {
		s := fmt.Sprintf("%d", i)
		b := tx.Bucket([]byte(s))
		if b == nil {
			t.Fatal(err)
		}
		if err := b.Delete([]byte(s)); err != nil {
			t.Fatal(err)
		}
	}
	if err := tx.Commit(); err != nil {
		t.Fatal(err)
	}
	db.MustClose()

	// Record freelist count from opening with NoFreelistSync.
	db.MustReopen()
	freepages := db.Stats().FreePageN
	if freepages == 0 {
		t.Fatalf("no free pages on NoFreelistSync reopen")
	}
	db.MustClose()

	// Check free page count is reconstructed when opened with freelist sync.
	db.SetOptions(&bolt.Options{})
	db.MustReopen()
	// One less free page for syncing the free list on open.
	freepages--
	if fp := db.Stats().FreePageN; fp < freepages {
		t.Fatalf("closed with %d free pages, opened with %d", freepages, fp)
	}
}

// Ensure that a database cannot open a transaction when it's not open.
func TestDB_Begin_ErrDatabaseNotOpen(t *testing.T) {
	var db bolt.DB
	if _, err := db.Begin(false); err != berrors.ErrDatabaseNotOpen {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure that a read-write transaction can be retrieved.
func TestDB_BeginRW(t *testing.T) {
	db := btesting.MustCreateDB(t)

	tx, err := db.Begin(true)
	require.NoError(t, err)
	require.NotNil(t, tx, "expected tx")
	defer func() { require.NoError(t, tx.Commit()) }()

	require.True(t, tx.Writable(), "expected writable tx")
	require.Same(t, db.DB, tx.DB())
}

// TestDB_Concurrent_WriteTo checks that issuing WriteTo operations concurrently
// with commits does not produce corrupted db files. It also verifies that all
// readonly transactions, which are created based on the same data view, should
// always read the same data.
func TestDB_Concurrent_WriteTo_and_ConsistentRead(t *testing.T) {
	o := &bolt.Options{
		NoFreelistSync: false,
		PageSize:       4096,
	}
	db := btesting.MustCreateDBWithOption(t, o)

	wtxs, rtxs := 50, 5
	bucketName := []byte("data")

	var dataLock sync.Mutex
	dataCache := make(map[int][]map[string]string)

	var wg sync.WaitGroup
	wg.Add(wtxs * rtxs)
	f := func(round int, tx *bolt.Tx) {
		defer wg.Done()
		time.Sleep(time.Duration(rand.Intn(200)+10) * time.Millisecond)
		f := filepath.Join(t.TempDir(), fmt.Sprintf("%d-bolt-", round))
		err := tx.CopyFile(f, 0600)
		require.NoError(t, err)

		// read all the data
		b := tx.Bucket(bucketName)
		data := make(map[string]string)
		err = b.ForEach(func(k, v []byte) error {
			data[string(k)] = string(v)
			return nil
		})
		require.NoError(t, err)

		// cache the data
		dataLock.Lock()
		dataSlice := dataCache[round]
		dataSlice = append(dataSlice, data)
		dataCache[round] = dataSlice
		dataLock.Unlock()

		err = tx.Rollback()
		require.NoError(t, err)

		copyOpt := *o
		snap := btesting.MustOpenDBWithOption(t, f, &copyOpt)
		defer snap.MustClose()
		snap.MustCheck()
	}

	err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket(bucketName)
		return err
	})
	require.NoError(t, err)

	for i := 0; i < wtxs; i++ {
		tx, err := db.Begin(true)
		require.NoError(t, err)

		b := tx.Bucket(bucketName)

		for j := 0; j < rtxs; j++ {
			rtx, rerr := db.Begin(false)
			require.NoError(t, rerr)
			go f(i, rtx)

			for k := 0; k < 10; k++ {
				key, value := fmt.Sprintf("key_%d", rand.Intn(10)), fmt.Sprintf("value_%d", rand.Intn(100))
				perr := b.Put([]byte(key), []byte(value))
				require.NoError(t, perr)
			}
		}
		err = tx.Commit()
		require.NoError(t, err)
	}
	wg.Wait()

	// compare the data. The data generated in the same round
	// should be exactly the same.
	for round, dataSlice := range dataCache {
		data0 := dataSlice[0]

		for i := 1; i < len(dataSlice); i++ {
			datai := dataSlice[i]
			same := reflect.DeepEqual(data0, datai)
			require.True(t, same, fmt.Sprintf("found inconsistent data in round %d, data[0]: %v, data[%d] : %v", round, data0, i, datai))
		}
	}
}

// TestDB_WriteTo_and_Overwrite verifies that `(tx *Tx) WriteTo` can still
// work even the underlying file is overwritten between the time a read-only
// transaction is created and the time the file is actually opened
func TestDB_WriteTo_and_Overwrite(t *testing.T) {
	testCases := []struct {
		name      string
		writeFlag int
	}{
		{
			name:      "writeFlag not set",
			writeFlag: 0,
		},
		/* syscall.O_DIRECT not supported on some platforms, i.e. Windows and MacOS
		{
			name:      "writeFlag set",
			writeFlag: syscall.O_DIRECT,
		},*/
	}

	fRead := func(db *bolt.DB, bucketName []byte) map[string]string {
		data := make(map[string]string)
		_ = db.View(func(tx *bolt.Tx) error {
			b := tx.Bucket(bucketName)
			berr := b.ForEach(func(k, v []byte) error {
				data[string(k)] = string(v)
				return nil
			})
			require.NoError(t, berr)
			return nil
		})
		return data
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			db := btesting.MustCreateDBWithOption(t, &bolt.Options{
				PageSize: 4096,
			})
			filePathOfDb := db.Path()

			var (
				bucketName   = []byte("data")
				dataExpected map[string]string
				dataActual   map[string]string
			)

			t.Log("Populate some data")
			err := db.Update(func(tx *bolt.Tx) error {
				b, berr := tx.CreateBucket(bucketName)
				if berr != nil {
					return berr
				}
				for k := 0; k < 10; k++ {
					key, value := fmt.Sprintf("key_%d", rand.Intn(10)), fmt.Sprintf("value_%d", rand.Intn(100))
					if perr := b.Put([]byte(key), []byte(value)); perr != nil {
						return perr
					}
				}
				return nil
			})
			require.NoError(t, err)

			t.Log("Read all the data before calling WriteTo")
			dataExpected = fRead(db.DB, bucketName)

			t.Log("Create a readonly transaction for WriteTo")
			rtx, rerr := db.Begin(false)
			require.NoError(t, rerr)

			// Some platforms (i.e. Windows) don't support renaming a file
			// when the target file already exist and is opened.
			if runtime.GOOS == "linux" {
				t.Log("Create another empty db file")
				db2 := btesting.MustCreateDBWithOption(t, &bolt.Options{
					PageSize: 4096,
				})
				db2.MustClose()
				filePathOfDb2 := db2.Path()

				t.Logf("Renaming the new empty db file (%s) to the original db path (%s)", filePathOfDb2, filePathOfDb)
				err = os.Rename(filePathOfDb2, filePathOfDb)
				require.NoError(t, err)
			} else {
				t.Log("Ignore renaming step on non-Linux platform")
			}

			t.Logf("Call WriteTo to copy the data of the original db file")
			f := filepath.Join(t.TempDir(), "-backup-db")
			err = rtx.CopyFile(f, 0600)
			require.NoError(t, err)
			require.NoError(t, rtx.Rollback())

			t.Logf("Read all the data from the backup db after calling WriteTo")
			newDB, err := bolt.Open(f, 0600, &bolt.Options{
				ReadOnly: true,
			})
			require.NoError(t, err)
			dataActual = fRead(newDB, bucketName)
			err = newDB.Close()
			require.NoError(t, err)

			t.Log("Compare the dataExpected and dataActual")
			same := reflect.DeepEqual(dataExpected, dataActual)
			require.True(t, same, fmt.Sprintf("found inconsistent data, dataExpected: %v, ddataActual : %v", dataExpected, dataActual))
		})
	}
}

// Ensure that opening a transaction while the DB is closed returns an error.
func TestDB_BeginRW_Closed(t *testing.T) {
	var db bolt.DB
	if _, err := db.Begin(true); err != berrors.ErrDatabaseNotOpen {
		t.Fatalf("unexpected error: %s", err)
	}
}

func TestDB_Close_PendingTx_RW(t *testing.T) { testDB_Close_PendingTx(t, true) }
func TestDB_Close_PendingTx_RO(t *testing.T) { testDB_Close_PendingTx(t, false) }

// Ensure that a database cannot close while transactions are open.
func testDB_Close_PendingTx(t *testing.T, writable bool) {
	db := btesting.MustCreateDB(t)

	// Start transaction.
	tx, err := db.Begin(writable)
	if err != nil {
		t.Fatal(err)
	}

	// Open update in separate goroutine.
	startCh := make(chan struct{}, 1)
	done := make(chan error, 1)
	go func() {
		startCh <- struct{}{}
		err := db.Close()
		done <- err
	}()
	// wait for the above goroutine to get scheduled.
	<-startCh

	// Ensure database hasn't closed.
	time.Sleep(100 * time.Millisecond)
	select {
	case err := <-done:
		if err != nil {
			t.Errorf("error from inside goroutine: %v", err)
		}
		t.Fatal("database closed too early")
	default:
	}

	// Commit/close transaction.
	if writable {
		err = tx.Commit()
	} else {
		err = tx.Rollback()
	}
	if err != nil {
		t.Fatal(err)
	}

	// Ensure database closed now.
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("error from inside goroutine: %v", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatalf("database did not close")
	}
}

// Ensure a database can provide a transactional block.
func TestDB_Update(t *testing.T) {
	db := btesting.MustCreateDB(t)
	if err := db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucket([]byte("widgets"))
		if err != nil {
			t.Fatal(err)
		}
		if err := b.Put([]byte("foo"), []byte("bar")); err != nil {
			t.Fatal(err)
		}
		if err := b.Put([]byte("baz"), []byte("bat")); err != nil {
			t.Fatal(err)
		}
		if err := b.Delete([]byte("foo")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("widgets"))
		if v := b.Get([]byte("foo")); v != nil {
			t.Fatalf("expected nil value, got: %v", v)
		}
		if v := b.Get([]byte("baz")); !bytes.Equal(v, []byte("bat")) {
			t.Fatalf("unexpected value: %v", v)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

// Ensure a closed database returns an error while running a transaction block
func TestDB_Update_Closed(t *testing.T) {
	var db bolt.DB
	if err := db.Update(func(tx *bolt.Tx) error {
		if _, err := tx.CreateBucket([]byte("widgets")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != berrors.ErrDatabaseNotOpen {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure a panic occurs while trying to commit a managed transaction.
func TestDB_Update_ManualCommit(t *testing.T) {
	db := btesting.MustCreateDB(t)

	var panicked bool
	if err := db.Update(func(tx *bolt.Tx) error {
		func() {
			defer func() {
				if r := recover(); r != nil {
					panicked = true
				}
			}()

			if err := tx.Commit(); err != nil {
				t.Fatal(err)
			}
		}()
		return nil
	}); err != nil {
		t.Fatal(err)
	} else if !panicked {
		t.Fatal("expected panic")
	}
}

// Ensure a panic occurs while trying to rollback a managed transaction.
func TestDB_Update_ManualRollback(t *testing.T) {
	db := btesting.MustCreateDB(t)

	var panicked bool
	if err := db.Update(func(tx *bolt.Tx) error {
		func() {
			defer func() {
				if r := recover(); r != nil {
					panicked = true
				}
			}()

			if err := tx.Rollback(); err != nil {
				t.Fatal(err)
			}
		}()
		return nil
	}); err != nil {
		t.Fatal(err)
	} else if !panicked {
		t.Fatal("expected panic")
	}
}

// Ensure a panic occurs while trying to commit a managed transaction.
func TestDB_View_ManualCommit(t *testing.T) {
	db := btesting.MustCreateDB(t)

	var panicked bool
	if err := db.View(func(tx *bolt.Tx) error {
		func() {
			defer func() {
				if r := recover(); r != nil {
					panicked = true
				}
			}()

			if err := tx.Commit(); err != nil {
				t.Fatal(err)
			}
		}()
		return nil
	}); err != nil {
		t.Fatal(err)
	} else if !panicked {
		t.Fatal("expected panic")
	}
}

// Ensure a panic occurs while trying to rollback a managed transaction.
func TestDB_View_ManualRollback(t *testing.T) {
	db := btesting.MustCreateDB(t)

	var panicked bool
	if err := db.View(func(tx *bolt.Tx) error {
		func() {
			defer func() {
				if r := recover(); r != nil {
					panicked = true
				}
			}()

			if err := tx.Rollback(); err != nil {
				t.Fatal(err)
			}
		}()
		return nil
	}); err != nil {
		t.Fatal(err)
	} else if !panicked {
		t.Fatal("expected panic")
	}
}

// Ensure a write transaction that panics does not hold open locks.
func TestDB_Update_Panic(t *testing.T) {
	db := btesting.MustCreateDB(t)

	// Panic during update but recover.
	func() {
		defer func() {
			if r := recover(); r != nil {
				t.Log("recover: update", r)
			}
		}()

		if err := db.Update(func(tx *bolt.Tx) error {
			if _, err := tx.CreateBucket([]byte("widgets")); err != nil {
				t.Fatal(err)
			}
			panic("omg")
		}); err != nil {
			t.Fatal(err)
		}
	}()

	// Verify we can update again.
	if err := db.Update(func(tx *bolt.Tx) error {
		if _, err := tx.CreateBucket([]byte("widgets")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}

	// Verify that our change persisted.
	if err := db.Update(func(tx *bolt.Tx) error {
		if tx.Bucket([]byte("widgets")) == nil {
			t.Fatal("expected bucket")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

// Ensure a database can return an error through a read-only transactional block.
func TestDB_View_Error(t *testing.T) {
	db := btesting.MustCreateDB(t)

	if err := db.View(func(tx *bolt.Tx) error {
		return errors.New("xxx")
	}); err == nil || err.Error() != "xxx" {
		t.Fatalf("unexpected error: %s", err)
	}
}

// Ensure a read transaction that panics does not hold open locks.
func TestDB_View_Panic(t *testing.T) {
	db := btesting.MustCreateDB(t)

	if err := db.Update(func(tx *bolt.Tx) error {
		if _, err := tx.CreateBucket([]byte("widgets")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}

	// Panic during view transaction but recover.
	func() {
		defer func() {
			if r := recover(); r != nil {
				t.Log("recover: view", r)
			}
		}()

		if err := db.View(func(tx *bolt.Tx) error {
			if tx.Bucket([]byte("widgets")) == nil {
				t.Fatal("expected bucket")
			}
			panic("omg")
		}); err != nil {
			t.Fatal(err)
		}
	}()

	// Verify that we can still use read transactions.
	if err := db.View(func(tx *bolt.Tx) error {
		if tx.Bucket([]byte("widgets")) == nil {
			t.Fatal("expected bucket")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

// Ensure that DB stats can be returned.
func TestDB_Stats(t *testing.T) {
	db := btesting.MustCreateDB(t)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("widgets"))
		return err
	}); err != nil {
		t.Fatal(err)
	}

	stats := db.Stats()
	if stats.TxStats.GetPageCount() != 2 {
		t.Fatalf("unexpected TxStats.PageCount: %d", stats.TxStats.GetPageCount())
	} else if stats.FreePageN != 0 {
		t.Fatalf("unexpected FreePageN != 0: %d", stats.FreePageN)
	} else if stats.PendingPageN != 2 {
		t.Fatalf("unexpected PendingPageN != 2: %d", stats.PendingPageN)
	}
}

// Ensure that database pages are in expected order and type.
func TestDB_Consistency(t *testing.T) {
	db := btesting.MustCreateDB(t)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("widgets"))
		return err
	}); err != nil {
		t.Fatal(err)
	}

	for i := 0; i < 10; i++ {
		if err := db.Update(func(tx *bolt.Tx) error {
			if err := tx.Bucket([]byte("widgets")).Put([]byte("foo"), []byte("bar")); err != nil {
				t.Fatal(err)
			}
			return nil
		}); err != nil {
			t.Fatal(err)
		}
	}

	if err := db.Update(func(tx *bolt.Tx) error {
		if p, _ := tx.Page(0); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "meta" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(1); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "meta" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(2); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "free" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(3); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "free" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(4); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "leaf" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(5); p == nil {
			t.Fatal("expected page")
		} else if p.Type != "freelist" {
			t.Fatalf("unexpected page type: %s", p.Type)
		}

		if p, _ := tx.Page(6); p != nil {
			t.Fatal("unexpected page")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

// Ensure that DB stats can be subtracted from one another.
func TestDBStats_Sub(t *testing.T) {
	var a, b bolt.Stats
	a.TxStats.PageCount = 3
	a.FreePageN = 4
	b.TxStats.PageCount = 10
	b.FreePageN = 14
	diff := b.Sub(&a)
	if diff.TxStats.GetPageCount() != 7 {
		t.Fatalf("unexpected TxStats.PageCount: %d", diff.TxStats.GetPageCount())
	}

	// free page stats are copied from the receiver and not subtracted
	if diff.FreePageN != 14 {
		t.Fatalf("unexpected FreePageN: %d", diff.FreePageN)
	}
}

// Ensure two functions can perform updates in a single batch.
func TestDB_Batch(t *testing.T) {
	db := btesting.MustCreateDB(t)

	if err := db.Update(func(tx *bolt.Tx) error {
		if _, err := tx.CreateBucket([]byte("widgets")); err != nil {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}

	// Iterate over multiple updates in separate goroutines.
	n := 2
	ch := make(chan error, n)
	for i := 0; i < n; i++ {
		go func(i int) {
			ch <- db.Batch(func(tx *bolt.Tx) error {
				return tx.Bucket([]byte("widgets")).Put(u64tob(uint64(i)), []byte{})
			})
		}(i)
	}

	// Check all responses to make sure there's no error.
	for i := 0; i < n; i++ {
		if err := <-ch; err != nil {
			t.Fatal(err)
		}
	}

	// Ensure data is correct.
	if err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("widgets"))
		for i := 0; i < n; i++ {
			if v := b.Get(u64tob(uint64(i))); v == nil {
				t.Errorf("key not found: %d", i)
			}
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

func TestDB_Batch_Panic(t *testing.T) {
	db := btesting.MustCreateDB(t)

	var sentinel int
	var bork = &sentinel
	var problem interface{}
	var err error

	// Execute a function inside a batch that panics.
	func() {
		defer func() {
			if p := recover(); p != nil {
				problem = p
			}
		}()
		err = db.Batch(func(tx *bolt.Tx) error {
			panic(bork)
		})
	}()

	// Verify there is no error.
	if g, e := err, error(nil); g != e {
		t.Fatalf("wrong error: %v != %v", g, e)
	}
	// Verify the panic was captured.
	if g, e := problem, bork; g != e {
		t.Fatalf("wrong error: %v != %v", g, e)
	}
}

func TestDB_BatchFull(t *testing.T) {
	db := btesting.MustCreateDB(t)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("widgets"))
		return err
	}); err != nil {
		t.Fatal(err)
	}

	const size = 3
	// buffered so we never leak goroutines
	ch := make(chan error, size)
	put := func(i int) {
		ch <- db.Batch(func(tx *bolt.Tx) error {
			return tx.Bucket([]byte("widgets")).Put(u64tob(uint64(i)), []byte{})
		})
	}

	db.MaxBatchSize = size
	// high enough to never trigger here
	db.MaxBatchDelay = 1 * time.Hour

	go put(1)
	go put(2)

	// Give the batch a chance to exhibit bugs.
	time.Sleep(10 * time.Millisecond)

	// not triggered yet
	select {
	case <-ch:
		t.Fatalf("batch triggered too early")
	default:
	}

	go put(3)

	// Check all responses to make sure there's no error.
	for i := 0; i < size; i++ {
		if err := <-ch; err != nil {
			t.Fatal(err)
		}
	}

	// Ensure data is correct.
	if err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("widgets"))
		for i := 1; i <= size; i++ {
			if v := b.Get(u64tob(uint64(i))); v == nil {
				t.Errorf("key not found: %d", i)
			}
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

func TestDB_BatchTime(t *testing.T) {
	db := btesting.MustCreateDB(t)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("widgets"))
		return err
	}); err != nil {
		t.Fatal(err)
	}

	const size = 1
	// buffered so we never leak goroutines
	ch := make(chan error, size)
	put := func(i int) {
		ch <- db.Batch(func(tx *bolt.Tx) error {
			return tx.Bucket([]byte("widgets")).Put(u64tob(uint64(i)), []byte{})
		})
	}

	db.MaxBatchSize = 1000
	db.MaxBatchDelay = 0

	go put(1)

	// Batch must trigger by time alone.

	// Check all responses to make sure there's no error.
	for i := 0; i < size; i++ {
		if err := <-ch; err != nil {
			t.Fatal(err)
		}
	}

	// Ensure data is correct.
	if err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("widgets"))
		for i := 1; i <= size; i++ {
			if v := b.Get(u64tob(uint64(i))); v == nil {
				t.Errorf("key not found: %d", i)
			}
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

// TestDBUnmap verifes that `dataref`, `data` and `datasz` must be reset
// to zero values respectively after unmapping the db.
func TestDBUnmap(t *testing.T) {
	db := btesting.MustCreateDB(t)

	require.NoError(t, db.DB.Close())

	// Ignore the following error:
	// Error: copylocks: call of reflect.ValueOf copies lock value: github.com/sagernet/bbolt.DB contains sync.Once contains sync.Mutex (govet)
	//nolint:govet
	v := reflect.ValueOf(*db.DB)
	dataref := v.FieldByName("dataref")
	data := v.FieldByName("data")
	datasz := v.FieldByName("datasz")
	assert.True(t, dataref.IsNil())
	assert.True(t, data.IsNil())
	assert.True(t, datasz.IsZero())

	// Set db.DB to nil to prevent MustCheck from panicking.
	db.DB = nil
}

// Convenience function for inserting a bunch of keys with values of a specific size (in bytes)
func fillDBWithKeys(db *btesting.DB, numKeys, valueSize int) error {
	return db.Fill([]byte("data"), 1, numKeys,
		func(tx int, k int) []byte { return []byte(fmt.Sprintf("%04d", k)) },
		func(tx int, k int) []byte { return make([]byte, valueSize) },
	)
}

// Creates a new database size, forces a specific allocation size jump, and fills it with the number of keys specified
func createFilledDB(t testing.TB, o *bolt.Options, allocSize int, numKeys int) *btesting.DB {
	// Open a data file.
	db := btesting.MustCreateDBWithOption(t, o)
	db.AllocSize = allocSize

	// Insert a reasonable amount of data below the max size.
	err := db.Fill([]byte("data"), 1, numKeys,
		func(tx int, k int) []byte { return []byte(fmt.Sprintf("%04d", k)) },
		func(tx int, k int) []byte { return make([]byte, 1000) },
	)
	if err != nil {
		t.Fatal(err)
	}
	return db
}

// Ensure that a database cannot exceed its maximum size
// https://github.com/etcd-io/bbolt/issues/928
func TestDB_MaxSizeNotExceeded(t *testing.T) {
	testCases := []struct {
		name    string
		options bolt.Options
	}{
		{
			name: "Standard case",
			options: bolt.Options{
				MaxSize:  5 * 1024 * 1024, // 5 MiB
				PageSize: 4096,
			},
		},
		{
			name: "NoGrowSync",
			options: bolt.Options{
				MaxSize:    5 * 1024 * 1024, // 5 MiB
				PageSize:   4096,
				NoGrowSync: true,
			},
		},
	}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			db := createFilledDB(t,
				&testCase.options,
				4*1024*1024, // adjust allocation jumps to 4 MiB
				2000,
			)

			path := db.Path()

			// The data file should be 4 MiB now (expanded once from zero).
			// It should have space for roughly one more entry with value size 100kB before trying to grow
			// This next insert should be too big
			err := fillDBWithKeys(db, 2, 100000)
			assert.ErrorIs(t, err, berrors.ErrMaxSizeReached)

			newSz := fileSize(path)
			require.Greater(t, newSz, int64(0), "unexpected new file size: %d", newSz)
			assert.LessOrEqual(t, newSz, int64(db.MaxSize), "The size of the data file should not exceed db.MaxSize")

			// Now try another write that shouldn't increase the max size
			err = fillDBWithKeys(db, 1, 1)
			assert.NoError(t, err, "Adding an entry after a failed, oversized write should not error")

			err = db.Close()
			require.NoError(t, err, "Closing the re-opened database should succeed")
		})
	}
}

// Ensure that opening a database that is beyond the maximum size succeeds
// The maximum size should only apply to growing the data file
// https://github.com/etcd-io/bbolt/issues/928
func TestDB_MaxSizeExceededCanOpen(t *testing.T) {
	// Open a data file.
	db := createFilledDB(t, nil, 4*1024*1024, 2000) // adjust allocation jumps to 4 MiB, fill with 2000, 1KB keys
	path := db.Path()

	// Insert a reasonable amount of data below the max size.
	err := fillDBWithKeys(db, 2000, 1000)
	require.NoError(t, err, "fillDbWithKeys should succeed")

	err = db.Close()
	require.NoError(t, err, "Close should succeed")

	// The data file should be 4 MiB now (expanded once from zero).
	minimumSizeForTest := int64(1024 * 1024)
	newSz := fileSize(path)
	require.GreaterOrEqual(t, newSz, minimumSizeForTest, "unexpected new file size: %d. Expected at least %d", newSz, minimumSizeForTest)

	// Now try to re-open the database with an extremely small max size
	t.Logf("Reopening bbolt DB at: %s", path)
	db, err = btesting.OpenDBWithOption(t, path, &bolt.Options{
		MaxSize: 1,
	})
	assert.NoError(t, err, "Should be able to open database bigger than MaxSize")

	err = db.Close()
	require.NoError(t, err, "Closing the re-opened database should succeed")
}

// Ensure that opening a database that is beyond the maximum size succeeds,
// even when InitialMmapSize is above the limit (mmaps should not affect file size)
// https://github.com/etcd-io/bbolt/issues/928
func TestDB_MaxSizeExceededCanOpenWithHighMmap(t *testing.T) {
	// Open a data file.
	db := createFilledDB(t, nil, 4*1024*1024, 2000) // adjust allocation jumps to 4 MiB, fill with 2000 1KB entries
	path := db.Path()

	err := db.Close()
	require.NoError(t, err, "Close should succeed")

	// The data file should be 4 MiB now (expanded once from zero).
	minimumSizeForTest := int64(1024 * 1024)
	newSz := fileSize(path)
	require.GreaterOrEqual(t, newSz, minimumSizeForTest, "unexpected new file size: %d. Expected at least %d", newSz, minimumSizeForTest)

	// Now try to re-open the database with an extremely small max size
	t.Logf("Reopening bbolt DB at: %s", path)
	db, err = btesting.OpenDBWithOption(t, path, &bolt.Options{
		MaxSize:         1,
		InitialMmapSize: int(minimumSizeForTest) * 2,
	})
	assert.NoError(t, err, "Should be able to open database bigger than MaxSize when InitialMmapSize set high")

	err = db.Close()
	require.NoError(t, err, "Closing the re-opened database should succeed")
}

// Ensure that on Windows, mmap never expands the file speculatively via
// InitialMmapSize, and that the database remains fully usable after such an
// open. https://github.com/etcd-io/bbolt/issues/928
func TestDB_MaxSizeExceededDoesNotGrow(t *testing.T) {
	if runtime.GOOS != "windows" {
		t.SkipNow()
	}

	// Build a filled database to use as the base for all sub-tests.
	// 4 MiB allocation jumps, 2000 × 1 KB entries → file lands at ~4 MiB.
	base := createFilledDB(t, nil, 4*1024*1024, 2000)
	basePath := base.Path()
	require.NoError(t, base.Close())

	baseSize := fileSize(basePath)
	require.Greater(t, baseSize, int64(1024*1024), "base DB too small for test: %d", baseSize)

	// copyDB snapshots the base file into a fresh temp path so each sub-test
	// gets an independent copy.
	copyDB := func(t *testing.T) string {
		t.Helper()
		data, err := os.ReadFile(basePath)
		require.NoError(t, err)
		dst := filepath.Join(t.TempDir(), "db")
		require.NoError(t, os.WriteFile(dst, data, 0600))
		return dst
	}

	testCases := []struct {
		name            string
		initialMmapSize int // 0 means unset
		maxSize         int // 0 means unset
		// expected file size after re-open (0 means "same as baseSize")
		wantSize    int64
		wantOpenErr error
	}{
		{
			// On Windows, mmap expands the file to the mapped size immediately.
			// When InitialMmapSize > MaxSize, the mmap call itself would grow the
			// file past MaxSize, so Open is rejected with ErrMaxSizeReached rather
			// than silently exceeding the limit.
			name:            "InitialMmapSize larger than file does not grow",
			initialMmapSize: int(baseSize) * 2,
			maxSize:         1,
			wantSize:        baseSize,
			wantOpenErr:     berrors.ErrMaxSizeReached,
		},
		{
			name:            "InitialMmapSize equal to file size does not grow",
			initialMmapSize: int(baseSize),
			maxSize:         1,
			wantSize:        baseSize,
		},
		{
			name:            "InitialMmapSize smaller than file size does not shrink",
			initialMmapSize: int(baseSize) / 2,
			maxSize:         1,
			wantSize:        baseSize,
		},
		{
			name:            "no InitialMmapSize does not grow",
			initialMmapSize: 0,
			maxSize:         1,
			wantSize:        baseSize,
		},
		{
			name:            "no MaxSize with high InitialMmapSize grows to InitialMmapSize",
			initialMmapSize: int(baseSize) * 2,
			maxSize:         0,
			wantSize:        baseSize * 2,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			path := copyDB(t)

			opts := &bolt.Options{InitialMmapSize: tc.initialMmapSize, MaxSize: tc.maxSize}

			db, err := btesting.OpenDBWithOption(t, path, opts)
			if tc.wantOpenErr != nil {
				require.ErrorIs(t, err, tc.wantOpenErr, "open should fail with expected error")
			} else {
				require.NoError(t, err, "open should succeed")
				db.MustClose()
			}

			got := fileSize(path)
			assert.Equal(t, tc.wantSize, got, "unexpected file size after re-open")
		})
	}
}

func TestDB_WindowsMMapReadsAndWritesWithMaxSize(t *testing.T) {
	if runtime.GOOS != "windows" {
		t.SkipNow()
	}

	base := createFilledDB(t, nil, 4*1024*1024, 2000)
	basePath := base.Path()
	require.NoError(t, base.Close())
	baseSize := fileSize(basePath)

	copyDB := func(t *testing.T) string {
		t.Helper()
		data, err := os.ReadFile(basePath)
		require.NoError(t, err)
		dst := filepath.Join(t.TempDir(), "db")
		require.NoError(t, os.WriteFile(dst, data, 0600))
		return dst
	}

	testCases := []struct {
		name            string
		initialMMapSize int
		maxSize         int
		op              func(db *btesting.DB) error
		wantOpErr       error
	}{
		{
			name:            "reads succeed after open with InitialMMapSize equal to file size",
			initialMMapSize: int(baseSize),
			maxSize:         1,
			op: func(db *btesting.DB) error {
				return db.View(func(tx *bolt.Tx) error {
					b := tx.Bucket([]byte("data"))
					require.NotNil(t, b, "bucket 'data' must exist")
					require.NotNil(t, b.Get([]byte("0001")), "key 0001 must be readable")
					return nil
				})
			},
		},
		{
			name:            "small writes succeed after open with high InitialMMapSize",
			initialMMapSize: int(baseSize) * 2,
			maxSize:         int(baseSize) * 4,
			op: func(db *btesting.DB) error {
				return fillDBWithKeys(db, 1, 1)
			},
		},
		{
			name:            "oversized writes return ErrMaxSizeReached",
			initialMMapSize: int(baseSize) / 2,
			maxSize:         int(baseSize),
			op: func(db *btesting.DB) error {
				return fillDBWithKeys(db, 2, 100000)
			},
			wantOpErr: berrors.ErrMaxSizeReached,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			path := copyDB(t)
			db, err := btesting.OpenDBWithOption(t, path, &bolt.Options{
				MaxSize:         tc.maxSize,
				InitialMmapSize: tc.initialMMapSize,
			})
			require.NoError(t, err)
			defer db.MustClose()

			opErr := tc.op(db)
			if tc.wantOpErr != nil {
				require.ErrorIs(t, opErr, tc.wantOpErr)
			} else {
				require.NoError(t, opErr)
			}
		})
	}
}

func TestDB_MaxSizeWithHighInitialMMapDoesNotGrowOnWrite(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.SkipNow()
	}

	maxSize := 64 * 1024 * 1024
	initialMMapSize := maxSize * 2
	valueSize := 50 * 1024 * 1024

	dbPath := filepath.Join(t.TempDir(), "db")
	db, err := bolt.Open(dbPath, 0600, &bolt.Options{
		MaxSize:         maxSize,
		InitialMmapSize: initialMMapSize,
	})
	require.NoError(t, err)
	defer func() {
		require.NoError(t, db.Close())
	}()

	value := bytes.Repeat([]byte("v"), valueSize)
	err = db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucket([]byte("data"))
		if err != nil {
			return err
		}
		return b.Put([]byte("large-value"), value)
	})
	assert.ErrorIs(t, err, berrors.ErrMaxSizeReached)

	newSz := fileSize(dbPath)
	assert.Greater(t, newSz, int64(0), "unexpected new file size: %d", newSz)
	assert.LessOrEqual(t, newSz, int64(maxSize), "The size of the data file should not exceed MaxSize")
}

func TestDB_HugeValue(t *testing.T) {
	dbPath := filepath.Join(t.TempDir(), "db")
	db, err := bolt.Open(dbPath, 0600, nil)
	require.NoError(t, err)
	defer func() {
		require.NoError(t, db.Close())
	}()

	maxSize := 0xFFFFFFF + 1
	// On 32 bit systems, the MaxAllocSize is 0xFFFFFFF (268435455,
	// roughly 256MB), and the test will fail for sure, so we reduce
	// the maxSize by half in such case.
	if maxSize > common.MaxAllocSize {
		maxSize = maxSize / 2
	}
	data := make([]byte, maxSize)

	_ = db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucketIfNotExists([]byte("data"))
		require.NoError(t, err)

		err = b.Put([]byte("key"), data)
		require.NoError(t, err)

		return nil
	})
}

func ExampleDB_Update() {
	// Open the database.
	db, err := bolt.Open(tempfile(), 0600, nil)
	if err != nil {
		log.Fatal(err)
	}
	defer os.Remove(db.Path())

	// Execute several commands within a read-write transaction.
	if err := db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucket([]byte("widgets"))
		if err != nil {
			return err
		}
		if err := b.Put([]byte("foo"), []byte("bar")); err != nil {
			return err
		}
		return nil
	}); err != nil {
		log.Fatal(err)
	}

	// Read the value back from a separate read-only transaction.
	if err := db.View(func(tx *bolt.Tx) error {
		value := tx.Bucket([]byte("widgets")).Get([]byte("foo"))
		fmt.Printf("The value of 'foo' is: %s\n", value)
		return nil
	}); err != nil {
		log.Fatal(err)
	}

	// Close database to release the file lock.
	if err := db.Close(); err != nil {
		log.Fatal(err)
	}

	// Output:
	// The value of 'foo' is: bar
}

func ExampleDB_View() {
	// Open the database.
	db, err := bolt.Open(tempfile(), 0600, nil)
	if err != nil {
		log.Fatal(err)
	}
	defer os.Remove(db.Path())

	// Insert data into a bucket.
	if err := db.Update(func(tx *bolt.Tx) error {
		b, err := tx.CreateBucket([]byte("people"))
		if err != nil {
			return err
		}
		if err := b.Put([]byte("john"), []byte("doe")); err != nil {
			return err
		}
		if err := b.Put([]byte("susy"), []byte("que")); err != nil {
			return err
		}
		return nil
	}); err != nil {
		log.Fatal(err)
	}

	// Access data from within a read-only transactional block.
	if err := db.View(func(tx *bolt.Tx) error {
		v := tx.Bucket([]byte("people")).Get([]byte("john"))
		fmt.Printf("John's last name is %s.\n", v)
		return nil
	}); err != nil {
		log.Fatal(err)
	}

	// Close database to release the file lock.
	if err := db.Close(); err != nil {
		log.Fatal(err)
	}

	// Output:
	// John's last name is doe.
}

func ExampleDB_Begin() {
	// Open the database.
	db, err := bolt.Open(tempfile(), 0600, nil)
	if err != nil {
		log.Fatal(err)
	}
	defer os.Remove(db.Path())

	// Create a bucket using a read-write transaction.
	if err = db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("widgets"))
		return err
	}); err != nil {
		log.Fatal(err)
	}

	// Create several keys in a transaction.
	tx, err := db.Begin(true)
	if err != nil {
		log.Fatal(err)
	}
	b := tx.Bucket([]byte("widgets"))
	if err = b.Put([]byte("john"), []byte("blue")); err != nil {
		log.Fatal(err)
	}
	if err = b.Put([]byte("abby"), []byte("red")); err != nil {
		log.Fatal(err)
	}
	if err = b.Put([]byte("zephyr"), []byte("purple")); err != nil {
		log.Fatal(err)
	}
	if err = tx.Commit(); err != nil {
		log.Fatal(err)
	}

	// Iterate over the values in sorted key order.
	tx, err = db.Begin(false)
	if err != nil {
		log.Fatal(err)
	}
	c := tx.Bucket([]byte("widgets")).Cursor()
	for k, v := c.First(); k != nil; k, v = c.Next() {
		fmt.Printf("%s likes %s\n", k, v)
	}

	if err = tx.Rollback(); err != nil {
		log.Fatal(err)
	}

	if err = db.Close(); err != nil {
		log.Fatal(err)
	}

	// Output:
	// abby likes red
	// john likes blue
	// zephyr likes purple
}

func BenchmarkDBBatchAutomatic(b *testing.B) {
	db := btesting.MustCreateDB(b)

	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("bench"))
		return err
	}); err != nil {
		b.Fatal(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		start := make(chan struct{})
		var wg sync.WaitGroup

		for round := 0; round < 1000; round++ {
			wg.Add(1)

			go func(id uint32) {
				defer wg.Done()
				<-start

				h := fnv.New32a()
				buf := make([]byte, 4)
				binary.LittleEndian.PutUint32(buf, id)
				_, _ = h.Write(buf[:])
				k := h.Sum(nil)
				insert := func(tx *bolt.Tx) error {
					b := tx.Bucket([]byte("bench"))
					return b.Put(k, []byte("filler"))
				}
				if err := db.Batch(insert); err != nil {
					b.Error(err)
					return
				}
			}(uint32(round))
		}
		close(start)
		wg.Wait()
	}

	b.StopTimer()
	validateBatchBench(b, db)
}

func BenchmarkDBBatchSingle(b *testing.B) {
	db := btesting.MustCreateDB(b)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("bench"))
		return err
	}); err != nil {
		b.Fatal(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		start := make(chan struct{})
		var wg sync.WaitGroup

		for round := 0; round < 1000; round++ {
			wg.Add(1)
			go func(id uint32) {
				defer wg.Done()
				<-start

				h := fnv.New32a()
				buf := make([]byte, 4)
				binary.LittleEndian.PutUint32(buf, id)
				_, _ = h.Write(buf[:])
				k := h.Sum(nil)
				insert := func(tx *bolt.Tx) error {
					b := tx.Bucket([]byte("bench"))
					return b.Put(k, []byte("filler"))
				}
				if err := db.Update(insert); err != nil {
					b.Error(err)
					return
				}
			}(uint32(round))
		}
		close(start)
		wg.Wait()
	}

	b.StopTimer()
	validateBatchBench(b, db)
}

func BenchmarkDBBatchManual10x100(b *testing.B) {
	db := btesting.MustCreateDB(b)
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucket([]byte("bench"))
		return err
	}); err != nil {
		b.Fatal(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		start := make(chan struct{})
		var wg sync.WaitGroup
		errCh := make(chan error, 10)

		for major := 0; major < 10; major++ {
			wg.Add(1)
			go func(id uint32) {
				defer wg.Done()
				<-start

				insert100 := func(tx *bolt.Tx) error {
					h := fnv.New32a()
					buf := make([]byte, 4)
					for minor := uint32(0); minor < 100; minor++ {
						binary.LittleEndian.PutUint32(buf, uint32(id*100+minor))
						h.Reset()
						_, _ = h.Write(buf[:])
						k := h.Sum(nil)
						b := tx.Bucket([]byte("bench"))
						if err := b.Put(k, []byte("filler")); err != nil {
							return err
						}
					}
					return nil
				}
				err := db.Update(insert100)
				errCh <- err
			}(uint32(major))
		}
		close(start)
		wg.Wait()
		close(errCh)
		for err := range errCh {
			if err != nil {
				b.Fatal(err)
			}
		}
	}

	b.StopTimer()
	validateBatchBench(b, db)
}

func validateBatchBench(b *testing.B, db *btesting.DB) {
	var rollback = errors.New("sentinel error to cause rollback")
	validate := func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("bench"))
		h := fnv.New32a()
		buf := make([]byte, 4)
		for id := uint32(0); id < 1000; id++ {
			binary.LittleEndian.PutUint32(buf, id)
			h.Reset()
			_, _ = h.Write(buf[:])
			k := h.Sum(nil)
			v := bucket.Get(k)
			if v == nil {
				b.Errorf("not found id=%d key=%x", id, k)
				continue
			}
			if g, e := v, []byte("filler"); !bytes.Equal(g, e) {
				b.Errorf("bad value for id=%d key=%x: %s != %q", id, k, g, e)
			}
			if err := bucket.Delete(k); err != nil {
				return err
			}
		}
		// should be empty now
		c := bucket.Cursor()
		for k, v := c.First(); k != nil; k, v = c.Next() {
			b.Errorf("unexpected key: %x = %q", k, v)
		}
		return rollback
	}
	if err := db.Update(validate); err != nil && err != rollback {
		b.Error(err)
	}
}

// tempfile returns a temporary file path.
func tempfile() string {
	f, err := os.CreateTemp("", "bolt-")
	if err != nil {
		panic(err)
	}
	if err := f.Close(); err != nil {
		panic(err)
	}
	if err := os.Remove(f.Name()); err != nil {
		panic(err)
	}
	return f.Name()
}

func trunc(b []byte, length int) []byte {
	if length < len(b) {
		return b[:length]
	}
	return b
}

func fileSize(path string) int64 {
	fi, err := os.Stat(path)
	if err != nil {
		return 0
	}
	return fi.Size()
}

// u64tob converts a uint64 into an 8-byte slice.
func u64tob(v uint64) []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, v)
	return b
}
