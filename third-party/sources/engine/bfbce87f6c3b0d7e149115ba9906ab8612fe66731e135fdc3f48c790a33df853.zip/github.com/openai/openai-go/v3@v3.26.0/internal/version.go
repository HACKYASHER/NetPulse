// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

package internal

const PackageVersion = "3.26.0" // x-release-please-version
