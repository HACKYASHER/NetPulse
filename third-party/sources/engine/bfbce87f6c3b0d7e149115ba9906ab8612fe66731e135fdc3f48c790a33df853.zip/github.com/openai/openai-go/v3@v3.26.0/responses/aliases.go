// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

package responses

import (
	"github.com/openai/openai-go/v3/internal/apierror"
	"github.com/openai/openai-go/v3/packages/param"
	"github.com/openai/openai-go/v3/shared"
)

// aliased to make [param.APIUnion] private when embedding
type paramUnion = param.APIUnion

// aliased to make [param.APIObject] private when embedding
type paramObj = param.APIObject

type Error = apierror.Error

// This is an alias to an internal type.
type ChatModel = shared.ChatModel

// Equals "gpt-5.4"
const ChatModelGPT5_4 = shared.ChatModelGPT5_4

// Equals "gpt-5.3-chat-latest"
const ChatModelGPT5_3ChatLatest = shared.ChatModelGPT5_3ChatLatest

// Equals "gpt-5.2"
const ChatModelGPT5_2 = shared.ChatModelGPT5_2

// Equals "gpt-5.2-2025-12-11"
const ChatModelGPT5_2_2025_12_11 = shared.ChatModelGPT5_2_2025_12_11

// Equals "gpt-5.2-chat-latest"
const ChatModelGPT5_2ChatLatest = shared.ChatModelGPT5_2ChatLatest

// Equals "gpt-5.2-pro"
const ChatModelGPT5_2Pro = shared.ChatModelGPT5_2Pro

// Equals "gpt-5.2-pro-2025-12-11"
const ChatModelGPT5_2Pro2025_12_11 = shared.ChatModelGPT5_2Pro2025_12_11

// Equals "gpt-5.1"
const ChatModelGPT5_1 = shared.ChatModelGPT5_1

// Equals "gpt-5.1-2025-11-13"
const ChatModelGPT5_1_2025_11_13 = shared.ChatModelGPT5_1_2025_11_13

// Equals "gpt-5.1-codex"
const ChatModelGPT5_1Codex = shared.ChatModelGPT5_1Codex

// Equals "gpt-5.1-mini"
const ChatModelGPT5_1Mini = shared.ChatModelGPT5_1Mini

// Equals "gpt-5.1-chat-latest"
const ChatModelGPT5_1ChatLatest = shared.ChatModelGPT5_1ChatLatest

// Equals "gpt-5"
const ChatModelGPT5 = shared.ChatModelGPT5

// Equals "gpt-5-mini"
const ChatModelGPT5Mini = shared.ChatModelGPT5Mini

// Equals "gpt-5-nano"
const ChatModelGPT5Nano = shared.ChatModelGPT5Nano

// Equals "gpt-5-2025-08-07"
const ChatModelGPT5_2025_08_07 = shared.ChatModelGPT5_2025_08_07

// Equals "gpt-5-mini-2025-08-07"
const ChatModelGPT5Mini2025_08_07 = shared.ChatModelGPT5Mini2025_08_07

// Equals "gpt-5-nano-2025-08-07"
const ChatModelGPT5Nano2025_08_07 = shared.ChatModelGPT5Nano2025_08_07

// Equals "gpt-5-chat-latest"
const ChatModelGPT5ChatLatest = shared.ChatModelGPT5ChatLatest

// Equals "gpt-4.1"
const ChatModelGPT4_1 = shared.ChatModelGPT4_1

// Equals "gpt-4.1-mini"
const ChatModelGPT4_1Mini = shared.ChatModelGPT4_1Mini

// Equals "gpt-4.1-nano"
const ChatModelGPT4_1Nano = shared.ChatModelGPT4_1Nano

// Equals "gpt-4.1-2025-04-14"
const ChatModelGPT4_1_2025_04_14 = shared.ChatModelGPT4_1_2025_04_14

// Equals "gpt-4.1-mini-2025-04-14"
const ChatModelGPT4_1Mini2025_04_14 = shared.ChatModelGPT4_1Mini2025_04_14

// Equals "gpt-4.1-nano-2025-04-14"
const ChatModelGPT4_1Nano2025_04_14 = shared.ChatModelGPT4_1Nano2025_04_14

// Equals "o4-mini"
const ChatModelO4Mini = shared.ChatModelO4Mini

// Equals "o4-mini-2025-04-16"
const ChatModelO4Mini2025_04_16 = shared.ChatModelO4Mini2025_04_16

// Equals "o3"
const ChatModelO3 = shared.ChatModelO3

// Equals "o3-2025-04-16"
const ChatModelO3_2025_04_16 = shared.ChatModelO3_2025_04_16

// Equals "o3-mini"
const ChatModelO3Mini = shared.ChatModelO3Mini

// Equals "o3-mini-2025-01-31"
const ChatModelO3Mini2025_01_31 = shared.ChatModelO3Mini2025_01_31

// Equals "o1"
const ChatModelO1 = shared.ChatModelO1

// Equals "o1-2024-12-17"
const ChatModelO1_2024_12_17 = shared.ChatModelO1_2024_12_17

// Equals "o1-preview"
const ChatModelO1Preview = shared.ChatModelO1Preview

// Equals "o1-preview-2024-09-12"
const ChatModelO1Preview2024_09_12 = shared.ChatModelO1Preview2024_09_12

// Equals "o1-mini"
const ChatModelO1Mini = shared.ChatModelO1Mini

// Equals "o1-mini-2024-09-12"
const ChatModelO1Mini2024_09_12 = shared.ChatModelO1Mini2024_09_12

// Equals "gpt-4o"
const ChatModelGPT4o = shared.ChatModelGPT4o

// Equals "gpt-4o-2024-11-20"
const ChatModelGPT4o2024_11_20 = shared.ChatModelGPT4o2024_11_20

// Equals "gpt-4o-2024-08-06"
const ChatModelGPT4o2024_08_06 = shared.ChatModelGPT4o2024_08_06

// Equals "gpt-4o-2024-05-13"
const ChatModelGPT4o2024_05_13 = shared.ChatModelGPT4o2024_05_13

// Equals "gpt-4o-audio-preview"
const ChatModelGPT4oAudioPreview = shared.ChatModelGPT4oAudioPreview

// Equals "gpt-4o-audio-preview-2024-10-01"
const ChatModelGPT4oAudioPreview2024_10_01 = shared.ChatModelGPT4oAudioPreview2024_10_01

// Equals "gpt-4o-audio-preview-2024-12-17"
const ChatModelGPT4oAudioPreview2024_12_17 = shared.ChatModelGPT4oAudioPreview2024_12_17

// Equals "gpt-4o-audio-preview-2025-06-03"
const ChatModelGPT4oAudioPreview2025_06_03 = shared.ChatModelGPT4oAudioPreview2025_06_03

// Equals "gpt-4o-mini-audio-preview"
const ChatModelGPT4oMiniAudioPreview = shared.ChatModelGPT4oMiniAudioPreview

// Equals "gpt-4o-mini-audio-preview-2024-12-17"
const ChatModelGPT4oMiniAudioPreview2024_12_17 = shared.ChatModelGPT4oMiniAudioPreview2024_12_17

// Equals "gpt-4o-search-preview"
const ChatModelGPT4oSearchPreview = shared.ChatModelGPT4oSearchPreview

// Equals "gpt-4o-mini-search-preview"
const ChatModelGPT4oMiniSearchPreview = shared.ChatModelGPT4oMiniSearchPreview

// Equals "gpt-4o-search-preview-2025-03-11"
const ChatModelGPT4oSearchPreview2025_03_11 = shared.ChatModelGPT4oSearchPreview2025_03_11

// Equals "gpt-4o-mini-search-preview-2025-03-11"
const ChatModelGPT4oMiniSearchPreview2025_03_11 = shared.ChatModelGPT4oMiniSearchPreview2025_03_11

// Equals "chatgpt-4o-latest"
const ChatModelChatgpt4oLatest = shared.ChatModelChatgpt4oLatest

// Equals "codex-mini-latest"
const ChatModelCodexMiniLatest = shared.ChatModelCodexMiniLatest

// Equals "gpt-4o-mini"
const ChatModelGPT4oMini = shared.ChatModelGPT4oMini

// Equals "gpt-4o-mini-2024-07-18"
const ChatModelGPT4oMini2024_07_18 = shared.ChatModelGPT4oMini2024_07_18

// Equals "gpt-4-turbo"
const ChatModelGPT4Turbo = shared.ChatModelGPT4Turbo

// Equals "gpt-4-turbo-2024-04-09"
const ChatModelGPT4Turbo2024_04_09 = shared.ChatModelGPT4Turbo2024_04_09

// Equals "gpt-4-0125-preview"
const ChatModelGPT4_0125Preview = shared.ChatModelGPT4_0125Preview

// Equals "gpt-4-turbo-preview"
const ChatModelGPT4TurboPreview = shared.ChatModelGPT4TurboPreview

// Equals "gpt-4-1106-preview"
const ChatModelGPT4_1106Preview = shared.ChatModelGPT4_1106Preview

// Equals "gpt-4-vision-preview"
const ChatModelGPT4VisionPreview = shared.ChatModelGPT4VisionPreview

// Equals "gpt-4"
const ChatModelGPT4 = shared.ChatModelGPT4

// Equals "gpt-4-0314"
const ChatModelGPT4_0314 = shared.ChatModelGPT4_0314

// Equals "gpt-4-0613"
const ChatModelGPT4_0613 = shared.ChatModelGPT4_0613

// Equals "gpt-4-32k"
const ChatModelGPT4_32k = shared.ChatModelGPT4_32k

// Equals "gpt-4-32k-0314"
const ChatModelGPT4_32k0314 = shared.ChatModelGPT4_32k0314

// Equals "gpt-4-32k-0613"
const ChatModelGPT4_32k0613 = shared.ChatModelGPT4_32k0613

// Equals "gpt-3.5-turbo"
const ChatModelGPT3_5Turbo = shared.ChatModelGPT3_5Turbo

// Equals "gpt-3.5-turbo-16k"
const ChatModelGPT3_5Turbo16k = shared.ChatModelGPT3_5Turbo16k

// Equals "gpt-3.5-turbo-0301"
const ChatModelGPT3_5Turbo0301 = shared.ChatModelGPT3_5Turbo0301

// Equals "gpt-3.5-turbo-0613"
const ChatModelGPT3_5Turbo0613 = shared.ChatModelGPT3_5Turbo0613

// Equals "gpt-3.5-turbo-1106"
const ChatModelGPT3_5Turbo1106 = shared.ChatModelGPT3_5Turbo1106

// Equals "gpt-3.5-turbo-0125"
const ChatModelGPT3_5Turbo0125 = shared.ChatModelGPT3_5Turbo0125

// Equals "gpt-3.5-turbo-16k-0613"
const ChatModelGPT3_5Turbo16k0613 = shared.ChatModelGPT3_5Turbo16k0613

// A filter used to compare a specified attribute key to a given value using a
// defined comparison operation.
//
// This is an alias to an internal type.
type ComparisonFilter = shared.ComparisonFilter

// Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
// `nin`.
//
// - `eq`: equals
// - `ne`: not equal
// - `gt`: greater than
// - `gte`: greater than or equal
// - `lt`: less than
// - `lte`: less than or equal
// - `in`: in
// - `nin`: not in
//
// This is an alias to an internal type.
type ComparisonFilterType = shared.ComparisonFilterType

// Equals "eq"
const ComparisonFilterTypeEq = shared.ComparisonFilterTypeEq

// Equals "ne"
const ComparisonFilterTypeNe = shared.ComparisonFilterTypeNe

// Equals "gt"
const ComparisonFilterTypeGt = shared.ComparisonFilterTypeGt

// Equals "gte"
const ComparisonFilterTypeGte = shared.ComparisonFilterTypeGte

// Equals "lt"
const ComparisonFilterTypeLt = shared.ComparisonFilterTypeLt

// Equals "lte"
const ComparisonFilterTypeLte = shared.ComparisonFilterTypeLte

// The value to compare against the attribute key; supports string, number, or
// boolean types.
//
// This is an alias to an internal type.
type ComparisonFilterValueUnion = shared.ComparisonFilterValueUnion

// This is an alias to an internal type.
type ComparisonFilterValueArrayItemUnion = shared.ComparisonFilterValueArrayItemUnion

// A filter used to compare a specified attribute key to a given value using a
// defined comparison operation.
//
// This is an alias to an internal type.
type ComparisonFilterParam = shared.ComparisonFilterParam

// The value to compare against the attribute key; supports string, number, or
// boolean types.
//
// This is an alias to an internal type.
type ComparisonFilterValueUnionParam = shared.ComparisonFilterValueUnionParam

// This is an alias to an internal type.
type ComparisonFilterValueArrayItemUnionParam = shared.ComparisonFilterValueArrayItemUnionParam

// Combine multiple filters using `and` or `or`.
//
// This is an alias to an internal type.
type CompoundFilter = shared.CompoundFilter

// Type of operation: `and` or `or`.
//
// This is an alias to an internal type.
type CompoundFilterType = shared.CompoundFilterType

// Equals "and"
const CompoundFilterTypeAnd = shared.CompoundFilterTypeAnd

// Equals "or"
const CompoundFilterTypeOr = shared.CompoundFilterTypeOr

// Combine multiple filters using `and` or `or`.
//
// This is an alias to an internal type.
type CompoundFilterParam = shared.CompoundFilterParam

// The input format for the custom tool. Default is unconstrained text.
//
// This is an alias to an internal type.
type CustomToolInputFormatUnion = shared.CustomToolInputFormatUnion

// Unconstrained free-form text.
//
// This is an alias to an internal type.
type CustomToolInputFormatText = shared.CustomToolInputFormatText

// A grammar defined by the user.
//
// This is an alias to an internal type.
type CustomToolInputFormatGrammar = shared.CustomToolInputFormatGrammar

// The input format for the custom tool. Default is unconstrained text.
//
// This is an alias to an internal type.
type CustomToolInputFormatUnionParam = shared.CustomToolInputFormatUnionParam

// Unconstrained free-form text.
//
// This is an alias to an internal type.
type CustomToolInputFormatTextParam = shared.CustomToolInputFormatTextParam

// A grammar defined by the user.
//
// This is an alias to an internal type.
type CustomToolInputFormatGrammarParam = shared.CustomToolInputFormatGrammarParam

// This is an alias to an internal type.
type ErrorObject = shared.ErrorObject

// This is an alias to an internal type.
type FunctionDefinition = shared.FunctionDefinition

// This is an alias to an internal type.
type FunctionDefinitionParam = shared.FunctionDefinitionParam

// The parameters the functions accepts, described as a JSON Schema object. See the
// [guide](https://platform.openai.com/docs/guides/function-calling) for examples,
// and the
// [JSON Schema reference](https://json-schema.org/understanding-json-schema/) for
// documentation about the format.
//
// Omitting `parameters` defines a function with an empty parameter list.
//
// This is an alias to an internal type.
type FunctionParameters = shared.FunctionParameters

// Set of 16 key-value pairs that can be attached to an object. This can be useful
// for storing additional information about the object in a structured format, and
// querying for objects via API or the dashboard.
//
// Keys are strings with a maximum length of 64 characters. Values are strings with
// a maximum length of 512 characters.
//
// This is an alias to an internal type.
type Metadata = shared.Metadata

// **gpt-5 and o-series models only**
//
// Configuration options for
// [reasoning models](https://platform.openai.com/docs/guides/reasoning).
//
// This is an alias to an internal type.
type Reasoning = shared.Reasoning

// **Deprecated:** use `summary` instead.
//
// A summary of the reasoning performed by the model. This can be useful for
// debugging and understanding the model's reasoning process. One of `auto`,
// `concise`, or `detailed`.
//
// This is an alias to an internal type.
type ReasoningGenerateSummary = shared.ReasoningGenerateSummary

// Equals "auto"
const ReasoningGenerateSummaryAuto = shared.ReasoningGenerateSummaryAuto

// Equals "concise"
const ReasoningGenerateSummaryConcise = shared.ReasoningGenerateSummaryConcise

// Equals "detailed"
const ReasoningGenerateSummaryDetailed = shared.ReasoningGenerateSummaryDetailed

// A summary of the reasoning performed by the model. This can be useful for
// debugging and understanding the model's reasoning process. One of `auto`,
// `concise`, or `detailed`.
//
// `concise` is supported for `computer-use-preview` models and all reasoning
// models after `gpt-5`.
//
// This is an alias to an internal type.
type ReasoningSummary = shared.ReasoningSummary

// Equals "auto"
const ReasoningSummaryAuto = shared.ReasoningSummaryAuto

// Equals "concise"
const ReasoningSummaryConcise = shared.ReasoningSummaryConcise

// Equals "detailed"
const ReasoningSummaryDetailed = shared.ReasoningSummaryDetailed

// **gpt-5 and o-series models only**
//
// Configuration options for
// [reasoning models](https://platform.openai.com/docs/guides/reasoning).
//
// This is an alias to an internal type.
type ReasoningParam = shared.ReasoningParam

// Constrains effort on reasoning for
// [reasoning models](https://platform.openai.com/docs/guides/reasoning). Currently
// supported values are `none`, `minimal`, `low`, `medium`, `high`, and `xhigh`.
// Reducing reasoning effort can result in faster responses and fewer tokens used
// on reasoning in a response.
//
//   - `gpt-5.1` defaults to `none`, which does not perform reasoning. The supported
//     reasoning values for `gpt-5.1` are `none`, `low`, `medium`, and `high`. Tool
//     calls are supported for all reasoning values in gpt-5.1.
//   - All models before `gpt-5.1` default to `medium` reasoning effort, and do not
//     support `none`.
//   - The `gpt-5-pro` model defaults to (and only supports) `high` reasoning effort.
//   - `xhigh` is supported for all models after `gpt-5.1-codex-max`.
//
// This is an alias to an internal type.
type ReasoningEffort = shared.ReasoningEffort

// Equals "none"
const ReasoningEffortNone = shared.ReasoningEffortNone

// Equals "minimal"
const ReasoningEffortMinimal = shared.ReasoningEffortMinimal

// Equals "low"
const ReasoningEffortLow = shared.ReasoningEffortLow

// Equals "medium"
const ReasoningEffortMedium = shared.ReasoningEffortMedium

// Equals "high"
const ReasoningEffortHigh = shared.ReasoningEffortHigh

// Equals "xhigh"
const ReasoningEffortXhigh = shared.ReasoningEffortXhigh

// JSON object response format. An older method of generating JSON responses. Using
// `json_schema` is recommended for models that support it. Note that the model
// will not generate JSON without a system or user message instructing it to do so.
//
// This is an alias to an internal type.
type ResponseFormatJSONObject = shared.ResponseFormatJSONObject

// JSON object response format. An older method of generating JSON responses. Using
// `json_schema` is recommended for models that support it. Note that the model
// will not generate JSON without a system or user message instructing it to do so.
//
// This is an alias to an internal type.
type ResponseFormatJSONObjectParam = shared.ResponseFormatJSONObjectParam

// JSON Schema response format. Used to generate structured JSON responses. Learn
// more about
// [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs).
//
// This is an alias to an internal type.
type ResponseFormatJSONSchema = shared.ResponseFormatJSONSchema

// Structured Outputs configuration options, including a JSON Schema.
//
// This is an alias to an internal type.
type ResponseFormatJSONSchemaJSONSchema = shared.ResponseFormatJSONSchemaJSONSchema

// JSON Schema response format. Used to generate structured JSON responses. Learn
// more about
// [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs).
//
// This is an alias to an internal type.
type ResponseFormatJSONSchemaParam = shared.ResponseFormatJSONSchemaParam

// Structured Outputs configuration options, including a JSON Schema.
//
// This is an alias to an internal type.
type ResponseFormatJSONSchemaJSONSchemaParam = shared.ResponseFormatJSONSchemaJSONSchemaParam

// Default response format. Used to generate text responses.
//
// This is an alias to an internal type.
type ResponseFormatText = shared.ResponseFormatText

// Default response format. Used to generate text responses.
//
// This is an alias to an internal type.
type ResponseFormatTextParam = shared.ResponseFormatTextParam

// This is an alias to an internal type.
type ResponsesModel = shared.ResponsesModel

// Equals "o1-pro"
const ResponsesModelO1Pro = shared.ResponsesModelO1Pro

// Equals "o1-pro-2025-03-19"
const ResponsesModelO1Pro2025_03_19 = shared.ResponsesModelO1Pro2025_03_19

// Equals "o3-pro"
const ResponsesModelO3Pro = shared.ResponsesModelO3Pro

// Equals "o3-pro-2025-06-10"
const ResponsesModelO3Pro2025_06_10 = shared.ResponsesModelO3Pro2025_06_10

// Equals "o3-deep-research"
const ResponsesModelO3DeepResearch = shared.ResponsesModelO3DeepResearch

// Equals "o3-deep-research-2025-06-26"
const ResponsesModelO3DeepResearch2025_06_26 = shared.ResponsesModelO3DeepResearch2025_06_26

// Equals "o4-mini-deep-research"
const ResponsesModelO4MiniDeepResearch = shared.ResponsesModelO4MiniDeepResearch

// Equals "o4-mini-deep-research-2025-06-26"
const ResponsesModelO4MiniDeepResearch2025_06_26 = shared.ResponsesModelO4MiniDeepResearch2025_06_26

// Equals "computer-use-preview"
const ResponsesModelComputerUsePreview = shared.ResponsesModelComputerUsePreview

// Equals "computer-use-preview-2025-03-11"
const ResponsesModelComputerUsePreview2025_03_11 = shared.ResponsesModelComputerUsePreview2025_03_11

// Equals "gpt-5-codex"
const ResponsesModelGPT5Codex = shared.ResponsesModelGPT5Codex

// Equals "gpt-5-pro"
const ResponsesModelGPT5Pro = shared.ResponsesModelGPT5Pro

// Equals "gpt-5-pro-2025-10-06"
const ResponsesModelGPT5Pro2025_10_06 = shared.ResponsesModelGPT5Pro2025_10_06

// Equals "gpt-5.1-codex-max"
const ResponsesModelGPT5_1CodexMax = shared.ResponsesModelGPT5_1CodexMax
