//go:build go1.26

package handshake

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/fips140"
	"fmt"
	"sync"

	"github.com/apernet/quic-go/internal/protocol"
)

// used for QUIC v1 (RFC 9000)
var retryAEADv1 = initAEAD([16]byte{0xbe, 0x0c, 0x69, 0x0b, 0x9f, 0x66, 0x57, 0x5a, 0x1d, 0x76, 0x6b, 0x54, 0xe3, 0x68, 0xc8, 0x4e})

// used for QUIC v2 (RFC 9369)
var retryAEADv2 = initAEAD([16]byte{0x8f, 0xb4, 0xb0, 0x1b, 0x56, 0xac, 0x48, 0xe2, 0x60, 0xfb, 0xcb, 0xce, 0xad, 0x7c, 0xcc, 0x92})

func initAEAD(key [16]byte) cipher.AEAD {
	aes, err := aes.NewCipher(key[:])
	if err != nil {
		panic(err)
	}
	var aead cipher.AEAD
	// Retry packet authentication uses the fixed key and nonce specified by RFC 9000.
	// It acts as an integrity tag for the Retry packet itself, protecting against
	// accidental modification and making injection harder. It is not used to encrypt
	// packet contents and therefore outside the scope of FIPS 140 enforcement.
	fips140.WithoutEnforcement(func() {
		var err error
		aead, err = cipher.NewGCM(aes)
		if err != nil {
			panic(err)
		}
	})
	return aead
}

var (
	retryBuf     bytes.Buffer
	retryMutex   sync.Mutex
	retryNonceV1 = [12]byte{0x46, 0x15, 0x99, 0xd3, 0x5d, 0x63, 0x2b, 0xf2, 0x23, 0x98, 0x25, 0xbb}
	retryNonceV2 = [12]byte{0xd8, 0x69, 0x69, 0xbc, 0x2d, 0x7c, 0x6d, 0x99, 0x90, 0xef, 0xb0, 0x4a}
)

// GetRetryIntegrityTag calculates the integrity tag on a Retry packet
func GetRetryIntegrityTag(retry []byte, origDestConnID protocol.ConnectionID, version protocol.Version) *[16]byte {
	retryMutex.Lock()
	defer retryMutex.Unlock()

	retryBuf.WriteByte(uint8(origDestConnID.Len()))
	retryBuf.Write(origDestConnID.Bytes())
	retryBuf.Write(retry)
	defer retryBuf.Reset()

	var tag [16]byte
	var sealed []byte
	if version == protocol.Version2 {
		sealed = retryAEADv2.Seal(tag[:0], retryNonceV2[:], nil, retryBuf.Bytes())
	} else {
		sealed = retryAEADv1.Seal(tag[:0], retryNonceV1[:], nil, retryBuf.Bytes())
	}
	if len(sealed) != 16 {
		panic(fmt.Sprintf("unexpected Retry integrity tag length: %d", len(sealed)))
	}
	return &tag
}
