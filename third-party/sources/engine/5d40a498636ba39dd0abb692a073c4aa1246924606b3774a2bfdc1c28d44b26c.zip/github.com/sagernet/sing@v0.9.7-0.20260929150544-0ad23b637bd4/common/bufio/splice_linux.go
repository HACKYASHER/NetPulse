package bufio

import (
	"syscall"

	E "github.com/sagernet/sing/common/exceptions"
	N "github.com/sagernet/sing/common/network"

	"golang.org/x/sys/unix"
)

const maxSpliceSize = 1 << 20

func splice(source syscall.RawConn, sourceReader N.SyscallReader, destination syscall.RawConn, destinationWriter N.SyscallWriter, readCounters []N.CountFunc, writeCounters []N.CountFunc) (handed bool, n int64, err error) {
	handed = true
	var pipeFDs [2]int
	err = unix.Pipe2(pipeFDs[:], syscall.O_CLOEXEC|syscall.O_NONBLOCK)
	if err != nil {
		return
	}
	defer unix.Close(pipeFDs[0])
	defer unix.Close(pipeFDs[1])
	_, _ = unix.FcntlInt(uintptr(pipeFDs[0]), unix.F_SETPIPE_SZ, maxSpliceSize)
	var (
		readN        int
		readErr      error
		writeSize    int
		writeErr     error
		notFirstTime bool
	)
	readFunc := func(fd uintptr) (done bool) {
		p0, p1 := unix.Splice(int(fd), nil, pipeFDs[1], nil, maxSpliceSize, unix.SPLICE_F_NONBLOCK)
		readN = int(p0)
		readErr = p1
		return readErr != unix.EAGAIN
	}
	writeFunc := func(fd uintptr) (done bool) {
		for writeSize > 0 {
			p0, p1 := unix.Splice(pipeFDs[0], nil, int(fd), nil, writeSize, unix.SPLICE_F_NONBLOCK|unix.SPLICE_F_MOVE)
			writeN := int(p0)
			writeErr = p1
			if writeErr != nil {
				return writeErr != unix.EAGAIN
			}
			writeSize -= writeN
		}
		return true
	}
	for {
		err = source.Read(readFunc)
		if readErr != nil {
			err = readErr
		}
		if err != nil {
			if sourceReader != nil {
				newBuffer, newErr := sourceReader.HandleSyscallReadError(err)
				if newErr != nil {
					err = newErr
				} else {
					err = nil
					if len(newBuffer) > 0 {
						readN, readErr = unix.Write(pipeFDs[1], newBuffer)
						if readErr != nil {
							err = E.Cause(err, "write handled data")
						}
					}
				}
			} else if !notFirstTime && E.IsMulti(err, unix.EINVAL, unix.ENOSYS) {
				handed = false
				return
			}
			err = E.Cause(err, "splice read")
			return
		}
		if readN == 0 {
			return
		}
		for _, readCounter := range readCounters {
			readCounter(int64(readN))
		}
		writeSize = readN
		err = destination.Write(writeFunc)
		if writeErr != nil {
			err = writeErr
		}
		written := int64(readN - writeSize)
		if written > 0 {
			n += written
			for _, writeCounter := range writeCounters {
				writeCounter(written)
			}
		}
		if err != nil {
			err = E.Cause(err, "splice write")
			return
		}
		notFirstTime = true
	}
}
