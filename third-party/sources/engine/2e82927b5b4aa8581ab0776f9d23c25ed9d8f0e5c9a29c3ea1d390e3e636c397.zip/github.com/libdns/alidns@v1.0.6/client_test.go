package alidns

import (
	"context"
	"testing"

	"github.com/libdns/libdns"
)

func Test_ClientAPIReq(t *testing.T) {
	p0.getClient()
	p0.client.SetRequestBody("Action", "DescribeDomainRecords")
	p0.client.SetRequestBody("KeyWords", "vi")
	var rs aliDomaRecords
	rspData := aliDomainResult{}
	err := p0.client.doAPIRequest(context.TODO(), &rspData)
	t.Log("req", p0.client.schema, "data", rspData, "err:", err, "rs:", rs)
}

func Test_QueryDomainRecord(t *testing.T) {
	r0, err := p0.queryDomainRecord(context.TODO(), "*", "aliyun.viscropst.ren", "A")
	t.Log("result:", r0)
	if err != nil {
		t.Log("err:", err)
		t.Fail()
	}
	t.Log("result with A rec:", r0, "err:", err)
}

func Test_QueryDomainRecords(t *testing.T) {
	r0, err := p0.queryDomainRecords(context.TODO(), "微明或鱼.中国")
	t.Log("result:", r0, "err:", err)

	recs, err := p0.GetRecords(context.TODO(),"微明或鱼.中国")
	t.Log("result:", recs, "err:", err)
}

func Test_DomainRecordOp(t *testing.T) {
	dr0 := aliDomainRecord{
		DomainName:  "viscrop.top",
		Rr:          "baidu",
		DomainType:  "CNAME",
		DomainValue: "baidu.com",
		TTL:         600,
	}
	r0, err := p0.addDomainRecord(context.TODO(), dr0)
	t.Log("result:", r0, "err:", err)
	dr0, err = p0.getDomainRecord(context.TODO(), r0)
	t.Log("result:", dr0, "err:", err)
	dr0.Rr = "bai"
	r0, err = p0.setDomainRecord(context.TODO(), dr0)
	t.Log("result:", r0, "err:", err)
	r0, err = p0.delDomainRecord(context.TODO(), dr0)
	t.Log("result:", r0, "err:", err)
}

func Test_SetDomainRecords(t *testing.T) {

	recs, err := p0.SetRecords(context.TODO(),"微明或鱼.中国",
	[]libdns.Record{libdns.TXT{
		Name: "你猜我是不是",
		Text: "I don't knows 23",
	}})
	t.Log("result:", recs, "err:", err)
}