// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

//go:build (ts_kube || (linux && (arm64 || amd64) && !android)) && !ts_omit_kube

package condregister

import _ "github.com/sagernet/tailscale/ipn/store/kubestore"
