// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

//go:build !ts_omit_osrouter

package condregister

import _ "github.com/sagernet/tailscale/wgengine/router/osrouter"
