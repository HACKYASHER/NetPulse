// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

//go:build ts_omit_debug && ts_omit_clientmetrics && ts_omit_usermetrics

package expvar

type Int int64

func (*Int) Add(int64) {}
