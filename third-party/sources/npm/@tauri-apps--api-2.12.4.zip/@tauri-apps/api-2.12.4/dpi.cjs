'use strict';

var core = require('./core.cjs');

// Copyright 2019-2024 Tauri Programme within The Commons Conservancy
// SPDX-License-Identifier: Apache-2.0
// SPDX-License-Identifier: MIT
/**
 * Size and position types for working with logical and physical pixels.
 *
 * Window and webview APIs report sizes and positions in **physical pixels** (actual
 * screen pixels), while most browser APIs and the window creation options use
 * **logical pixels** (physical pixels divided by the monitor scale factor). The
 * classes in this module make the unit explicit and convert between the two.
 *
 * ```typescript
 * import { getCurrentWindow } from '@tauri-apps/api/window';
 *
 * const appWindow = getCurrentWindow();
 * const size = await appWindow.innerSize(); // PhysicalSize
 * const logical = size.toLogical(await appWindow.scaleFactor());
 * ```
 *
 * They also serialize into the shape `tauri::Size` / `tauri::Position` expect, so
 * they can be passed straight to your own commands, see {@linkcode Size} and
 * {@linkcode Position}.
 *
 * This package is also accessible with `window.__TAURI__.dpi` when [`app.withGlobalTauri`](https://v2.tauri.app/reference/config/#withglobaltauri) in `tauri.conf.json` is set to `true`.
 *
 * @module
 */
/**
 * A size represented in logical pixels.
 * Logical pixels are scaled according to the window's DPI scale.
 * Most browser APIs (i.e. `MouseEvent`'s `clientX`) will return logical pixels.
 *
 * For logical-pixel-based position, see {@linkcode LogicalPosition}.
 *
 * @since 2.0.0
 */
class LogicalSize {
    constructor(...args) {
        this.type = 'Logical';
        if (args.length === 1) {
            if ('Logical' in args[0]) {
                this.width = args[0].Logical.width;
                this.height = args[0].Logical.height;
            }
            else {
                this.width = args[0].width;
                this.height = args[0].height;
            }
        }
        else {
            this.width = args[0];
            this.height = args[1];
        }
    }
    /**
     * Converts the logical size to a physical one.
     * @example
     * ```typescript
     * import { LogicalSize } from '@tauri-apps/api/dpi';
     * import { getCurrentWindow } from '@tauri-apps/api/window';
     *
     * const appWindow = getCurrentWindow();
     * const factor = await appWindow.scaleFactor();
     * const size = new LogicalSize(400, 500);
     * const physical = size.toPhysical(factor);
     * ```
     *
     * @since 2.0.0
     */
    toPhysical(scaleFactor) {
        return new PhysicalSize(this.width * scaleFactor, this.height * scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            width: this.width,
            height: this.height
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}
/**
 * A size represented in physical pixels.
 *
 * Physical pixels represent actual screen pixels, and are DPI-independent.
 * For high-DPI windows, this means that any point in the window on the screen
 * will have a different position in logical pixels {@linkcode LogicalSize}.
 *
 * For physical-pixel-based position, see {@linkcode PhysicalPosition}.
 *
 * @since 2.0.0
 */
class PhysicalSize {
    constructor(...args) {
        this.type = 'Physical';
        if (args.length === 1) {
            if ('Physical' in args[0]) {
                this.width = args[0].Physical.width;
                this.height = args[0].Physical.height;
            }
            else {
                this.width = args[0].width;
                this.height = args[0].height;
            }
        }
        else {
            this.width = args[0];
            this.height = args[1];
        }
    }
    /**
     * Converts the physical size to a logical one.
     * @example
     * ```typescript
     * import { getCurrentWindow } from '@tauri-apps/api/window';
     * const appWindow = getCurrentWindow();
     * const factor = await appWindow.scaleFactor();
     * const size = await appWindow.innerSize(); // PhysicalSize
     * const logical = size.toLogical(factor);
     * ```
     *
     * @since 2.0.0
     */
    toLogical(scaleFactor) {
        return new LogicalSize(this.width / scaleFactor, this.height / scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            width: this.width,
            height: this.height
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}
/**
 * A size represented either in physical or in logical pixels.
 *
 * This type is basically a union type of {@linkcode LogicalSize} and {@linkcode PhysicalSize}
 * but comes in handy when using `tauri::Size` in Rust as an argument to a command, as this class
 * automatically serializes into a valid format so it can be deserialized correctly into `tauri::Size`
 *
 * So instead of
 * ```typescript
 * import { invoke } from '@tauri-apps/api/core';
 * import { LogicalSize, PhysicalSize } from '@tauri-apps/api/dpi';
 *
 * const size: LogicalSize | PhysicalSize = someFunction(); // where someFunction returns either LogicalSize or PhysicalSize
 * const validSize = size instanceof LogicalSize
 *   ? { Logical: { width: size.width, height: size.height } }
 *   : { Physical: { width: size.width, height: size.height } }
 * await invoke("do_something_with_size", { size: validSize });
 * ```
 *
 * You can just use {@linkcode Size}
 * ```typescript
 * import { invoke } from '@tauri-apps/api/core';
 * import { LogicalSize, PhysicalSize, Size } from '@tauri-apps/api/dpi';
 *
 * const size: LogicalSize | PhysicalSize = someFunction(); // where someFunction returns either LogicalSize or PhysicalSize
 * const validSize = new Size(size);
 * await invoke("do_something_with_size", { size: validSize });
 * ```
 *
 * @since 2.1.0
 */
class Size {
    constructor(size) {
        this.size = size;
    }
    /**
     * Converts the wrapped size to a logical one.
     *
     * Returns the inner value untouched when it already is a {@linkcode LogicalSize}.
     *
     * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
     *
     * @since 2.1.0
     */
    toLogical(scaleFactor) {
        return this.size instanceof LogicalSize
            ? this.size
            : this.size.toLogical(scaleFactor);
    }
    /**
     * Converts the wrapped size to a physical one.
     *
     * Returns the inner value untouched when it already is a {@linkcode PhysicalSize}.
     *
     * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
     *
     * @since 2.1.0
     */
    toPhysical(scaleFactor) {
        return this.size instanceof PhysicalSize
            ? this.size
            : this.size.toPhysical(scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            [`${this.size.type}`]: {
                width: this.size.width,
                height: this.size.height
            }
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}
/**
 * A position represented in logical pixels.
 * For an explanation of what logical pixels are, see description of {@linkcode LogicalSize}.
 *
 * @since 2.0.0
 */
class LogicalPosition {
    constructor(...args) {
        this.type = 'Logical';
        if (args.length === 1) {
            if ('Logical' in args[0]) {
                this.x = args[0].Logical.x;
                this.y = args[0].Logical.y;
            }
            else {
                this.x = args[0].x;
                this.y = args[0].y;
            }
        }
        else {
            this.x = args[0];
            this.y = args[1];
        }
    }
    /**
     * Converts the logical position to a physical one.
     * @example
     * ```typescript
     * import { LogicalPosition } from '@tauri-apps/api/dpi';
     * import { getCurrentWindow } from '@tauri-apps/api/window';
     *
     * const appWindow = getCurrentWindow();
     * const factor = await appWindow.scaleFactor();
     * const position = new LogicalPosition(400, 500);
     * const physical = position.toPhysical(factor);
     * ```
     *
     * @since 2.0.0
     */
    toPhysical(scaleFactor) {
        return new PhysicalPosition(this.x * scaleFactor, this.y * scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            x: this.x,
            y: this.y
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}
/**
 * A position represented in physical pixels.
 *
 * For an explanation of what physical pixels are, see description of {@linkcode PhysicalSize}.
 *
 * @since 2.0.0
 */
class PhysicalPosition {
    constructor(...args) {
        this.type = 'Physical';
        if (args.length === 1) {
            if ('Physical' in args[0]) {
                this.x = args[0].Physical.x;
                this.y = args[0].Physical.y;
            }
            else {
                this.x = args[0].x;
                this.y = args[0].y;
            }
        }
        else {
            this.x = args[0];
            this.y = args[1];
        }
    }
    /**
     * Converts the physical position to a logical one.
     * @example
     * ```typescript
     * import { PhysicalPosition } from '@tauri-apps/api/dpi';
     * import { getCurrentWindow } from '@tauri-apps/api/window';
     *
     * const appWindow = getCurrentWindow();
     * const factor = await appWindow.scaleFactor();
     * const position = new PhysicalPosition(400, 500);
     * const logical = position.toLogical(factor);
     * ```
     *
     * @since 2.0.0
     */
    toLogical(scaleFactor) {
        return new LogicalPosition(this.x / scaleFactor, this.y / scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            x: this.x,
            y: this.y
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}
/**
 * A position represented either in physical or in logical pixels.
 *
 * This type is basically a union type of {@linkcode LogicalPosition} and {@linkcode PhysicalPosition}
 * but comes in handy when using `tauri::Position` in Rust as an argument to a command, as this class
 * automatically serializes into a valid format so it can be deserialized correctly into `tauri::Position`
 *
 * So instead of
 * ```typescript
 * import { invoke } from '@tauri-apps/api/core';
 * import { LogicalPosition, PhysicalPosition } from '@tauri-apps/api/dpi';
 *
 * const position: LogicalPosition | PhysicalPosition = someFunction(); // where someFunction returns either LogicalPosition or PhysicalPosition
 * const validPosition = position instanceof LogicalPosition
 *   ? { Logical: { x: position.x, y: position.y } }
 *   : { Physical: { x: position.x, y: position.y } }
 * await invoke("do_something_with_position", { position: validPosition });
 * ```
 *
 * You can just use {@linkcode Position}
 * ```typescript
 * import { invoke } from '@tauri-apps/api/core';
 * import { LogicalPosition, PhysicalPosition, Position } from '@tauri-apps/api/dpi';
 *
 * const position: LogicalPosition | PhysicalPosition = someFunction(); // where someFunction returns either LogicalPosition or PhysicalPosition
 * const validPosition = new Position(position);
 * await invoke("do_something_with_position", { position: validPosition });
 * ```
 *
 * @since 2.1.0
 */
class Position {
    constructor(position) {
        this.position = position;
    }
    /**
     * Converts the wrapped position to a logical one.
     *
     * Returns the inner value untouched when it already is a {@linkcode LogicalPosition}.
     *
     * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
     *
     * @since 2.1.0
     */
    toLogical(scaleFactor) {
        return this.position instanceof LogicalPosition
            ? this.position
            : this.position.toLogical(scaleFactor);
    }
    /**
     * Converts the wrapped position to a physical one.
     *
     * Returns the inner value untouched when it already is a {@linkcode PhysicalPosition}.
     *
     * @param scaleFactor The monitor scale factor, e.g. `await appWindow.scaleFactor()`.
     *
     * @since 2.1.0
     */
    toPhysical(scaleFactor) {
        return this.position instanceof PhysicalPosition
            ? this.position
            : this.position.toPhysical(scaleFactor);
    }
    [core.SERIALIZE_TO_IPC_FN]() {
        return {
            [`${this.position.type}`]: {
                x: this.position.x,
                y: this.position.y
            }
        };
    }
    toJSON() {
        // eslint-disable-next-line security/detect-object-injection
        return this[core.SERIALIZE_TO_IPC_FN]();
    }
}

exports.LogicalPosition = LogicalPosition;
exports.LogicalSize = LogicalSize;
exports.PhysicalPosition = PhysicalPosition;
exports.PhysicalSize = PhysicalSize;
exports.Position = Position;
exports.Size = Size;
